<?php
require_once "Config/conf.php";
require_once "Config/helpers.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$products = [];

if (!empty($keyword)) {
    $stmt = $conn->prepare("SELECT * FROM `products` WHERE `title` LIKE ? OR `description` LIKE ? ORDER BY `id` DESC");
    $searchTerm = "%" . $keyword . "%";
    $stmt->execute([$searchTerm, $searchTerm]);
    $products = $stmt->fetchAll();
}

$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();
$categories = $conn->query("SELECT * FROM `categoris` ORDER BY `id` DESC")->fetchAll();
$brands = $conn->query("SELECT * FROM `brands` WHERE `is_active` = 1 ORDER BY `id` DESC LIMIT 6")->fetchAll();

if (!isset($_SESSION['city'])) {
    $_SESSION['city'] = 'تهران';
}

if (isset($_POST['city'])) {
    $_SESSION['city'] = $_POST['city'];
    header("Location: /shop/search.php?q=" . urlencode($keyword));
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتایج جستجو · <?= htmlspecialchars($settings['title'] ?? 'فروشگاه ارن') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f5f5f5;color:#1a1a1a;}
        .line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
        .deal-item{transition:all 0.3s ease;position:relative;overflow:hidden;}
        .deal-item:hover{transform:translateY(-5px);box-shadow:0 10px 40px rgba(0,0,0,0.1);}
        .product-img{width:100%;height:200px;object-fit:contain;border-radius:8px;background:#f8fafc;}
        .btn-cart{background:#dc2626;color:#fff;padding:6px 16px;border:none;border-radius:8px;font-size:13px;font-weight:600;transition:all 0.3s ease;cursor:pointer;display:inline-flex;align-items:center;gap:6px;width:100%;justify-content:center;text-decoration:none;}
        .btn-cart:hover{background:#b91c1c;transform:translateY(-2px);box-shadow:0 8px 25px rgba(220,38,38,0.3);color:#fff;}
        .stars{color:#fbbf24;font-size:12px;}
        .stars .empty{color:#d1d5db;}
        .old-price{text-decoration:line-through;color:#9ca3af;font-size:13px;}
        .current-price{color:#dc2626;font-weight:700;font-size:16px;}
        .location-dropdown{position:relative;display:inline-block;cursor:pointer;}
        .location-dropdown .dropdown-menu{display:none;position:absolute;top:100%;right:0;background:#fff;min-width:200px;max-height:300px;overflow-y:auto;box-shadow:0 10px 40px rgba(0,0,0,0.15);border-radius:12px;padding:8px 0;z-index:1000;border:1px solid #e5e7eb;margin-top:5px;}
        .location-dropdown:hover .dropdown-menu{display:block;}
        .location-dropdown .dropdown-item{padding:10px 20px;color:#1a1a1a;text-decoration:none;display:block;font-size:14px;transition:all 0.2s;border:none;background:none;width:100%;text-align:right;cursor:pointer;font-family:inherit;}
        .location-dropdown .dropdown-item:hover{background:#f3f4f6;color:#dc2626;}
        .location-dropdown .dropdown-item.active{background:#dc2626;color:#fff;}
        .location-dropdown .dropdown-item i{margin-left:10px;color:#dc2626;width:18px;}
        .location-btn{background:none;border:none;color:#2563eb;font-weight:600;font-size:14px;cursor:pointer;display:flex;align-items:center;gap:6px;font-family:inherit;padding:4px 8px;border-radius:8px;transition:all 0.2s;}
        .location-btn:hover{background:#eff6ff;}
        .location-btn i{color:#2563eb;font-size:16px;}
        .location-current{color:#1a1a1a;font-weight:600;margin-left:4px;}
        .location-label{color:#6b7280;font-size:14px;}
        .empty-state{text-align:center;padding:60px 20px;}
        .empty-state i{font-size:4rem;color:#dc2626;margin-bottom:15px;}
        .empty-state h3{font-size:1.3rem;color:#1a1a1a;margin-bottom:8px;}
        .empty-state p{color:#6b7280;}
        .search-box{position:relative;}
        .search-box input{padding-left:50px;}
        .search-box button{position:absolute;left:0;top:0;height:100%;background:#dc2626;color:#fff;border:none;padding:0 18px;border-radius:0 12px 12px 0;cursor:pointer;transition:0.3s;}
        .search-box button:hover{background:#b91c1c;}
    </style>
</head>
<body>

<header class="bg-white shadow-sm sticky top-0 z-50">
    <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <a href="/shop/index.php" class="text-2xl font-bold text-red-600">ارن</a>
                <span class="mr-2 text-xs text-gray-500 hidden sm:inline">خرید هوشمند، زندگی آسان</span>
            </div>
            <div class="flex-1 mx-4 max-w-xl hidden md:block">
                <form action="/shop/search.php" method="GET" class="relative">
                    <input type="text" name="q" placeholder="جستجو..." value="<?= htmlspecialchars($keyword) ?>" class="w-full border border-gray-300 rounded-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-red-500" style="padding-left:50px;">
                    <button type="submit" class="absolute left-0 top-0 h-full bg-red-600 text-white px-4 rounded-l-md hover:bg-red-700"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="flex items-center space-x-4 space-x-reverse">
                <a href="/shop/cart.php" class="text-gray-700 hover:text-red-600 relative">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span class="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"><?php $c=0;if(isset($_SESSION['cart'])){foreach($_SESSION['cart'] as $item){$c+=$item['quantity'];}}echo $c;?></span>
                </a>
                <a href="/shop/login.php" class="text-gray-700 hover:text-red-600"><i class="fas fa-user text-xl"></i></a>
            </div>
        </div>
    </div>
</header>

<div class="bg-blue-50 py-2 px-4 text-sm border-b border-blue-100">
    <div class="container mx-auto flex items-center">
        <div class="flex items-center">
            <i class="fas fa-map-marker-alt text-blue-600 ml-2"></i>
            <span class="location-label">آدرس تحویل:</span>
            <div class="location-dropdown mr-2">
                <button class="location-btn"><i class="fas fa-chevron-down"></i><span class="location-current"><?= htmlspecialchars($_SESSION['city']) ?></span></button>
                <div class="dropdown-menu">
                    <form method="POST" action="">
                        <?php $cities = ['تهران','مشهد','اصفهان','شیراز','تبریز','کرج','قم','اهواز','کرمانشاه','رشت','زاهدان','ارومیه','یزد','همدان','کرمان','اراک','اسلامشهر','قزوین','زنجان','سنندج','خرم‌آباد','بندرعباس','بوشهر','ساری','بابل','آمل','بیرجند','گرگان','شاهرود','سمنان']; foreach($cities as $city): ?>
                            <button type="submit" name="city" value="<?= $city ?>" class="dropdown-item <?= ($_SESSION['city'] == $city) ? 'active' : '' ?>"><i class="fas fa-map-pin"></i> <?= $city ?></button>
                        <?php endforeach; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<main class="container mx-auto px-4 py-6">

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">نتایج جستجو برای: "<?= htmlspecialchars($keyword) ?>"</h1>
        <p class="text-gray-500 text-sm mt-1"><?= count($products) ?> محصول یافت شد</p>
    </div>

    <?php if (!empty($keyword) && count($products) > 0): ?>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <?php foreach ($products as $product): ?>
                <div class="deal-item border border-gray-200 rounded-lg p-3 bg-white">
                    <div class="img-wrapper" style="height:200px;overflow:hidden;border-radius:8px;background:#f8fafc;display:flex;align-items:center;justify-content:center;">
                        <?php if (!empty($product['image']) && $product['image'] != "default-image.jpg" && file_exists("Public/products/" . $product['image'])): ?>
                            <img class="product-img" src="<?= Assets("products/" . $product['image']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
                        <?php else: ?>
                            <img class="product-img" src="<?= Assets("products/default-image.jpg") ?>" alt="پیش‌فرض">
                        <?php endif; ?>
                    </div>
                    <h3 class="text-sm font-medium mt-2 line-clamp-2" style="height:40px;"><?= htmlspecialchars($product['title']) ?></h3>
                    <div class="flex items-center mt-1">
                        <?php if (!empty($product['old_price'])): ?><span class="old-price ml-2"><?= number_format($product['old_price']) ?> تومان</span><?php endif; ?>
                        <span class="current-price"><?= number_format($product['price']) ?> تومان</span>
                    </div>
                    <div class="flex items-center mt-2">
                        <div class="stars"><?php $rating = round($product['rating'] ?? 0); for($i=1;$i<=5;$i++): ?><?php if($i<=$rating): ?><i class="fas fa-star"></i><?php else: ?><i class="fas fa-star empty"></i><?php endif; ?><?php endfor; ?></div>
                        <span class="text-xs text-gray-500 mr-1">(<?= $product['review_count'] ?? 0 ?>)</span>
                    </div>
                    <a href="/shop/index.php?add=<?= $product['id'] ?>" class="btn-cart mt-2"><i class="fas fa-cart-plus"></i> افزودن به سبد</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif (!empty($keyword) && count($products) == 0): ?>
        <div class="empty-state"><i class="fas fa-search"></i><h3>نتیجه‌ای یافت نشد!</h3><p>برای "<?= htmlspecialchars($keyword) ?>" هیچ محصولی پیدا نشد.</p><a href="/shop/index.php" class="inline-block mt-4 bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">بازگشت به صفحه اصلی</a></div>
    <?php else: ?>
        <div class="empty-state"><i class="fas fa-search"></i><h3>عبارت جستجو را وارد کنید</h3><p>برای جستجو، کلمه مورد نظر را در باکس جستجو وارد کنید.</p></div>
    <?php endif; ?>

</main>

<!-- =============== FOOTER =============== -->
<div style="background:#1a1a1a; color:white; padding:30px 20px; margin-top:30px; text-align:center; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
    <div style="max-width:1200px; margin:0 auto;">
        <h4 style="font-size:22px; font-weight:700; margin-bottom:10px; color:#fff;">ارن</h4>
        <p style="color:#9ca3af; font-size:14px; margin-bottom:15px;">بهترین فروشگاه آنلاین با بهترین قیمت‌ها</p>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">درباره ما</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">تماس با ما</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">حریم خصوصی</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">شرایط استفاده</a>
        </div>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">راهنما</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">پرسش‌های متداول</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">بازگشت کالا</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">گارانتی</a>
        </div>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-phone" style="color:#dc2626; margin-left:5px;"></i> ۰۲۱-۱۲۳۴۵۶۷۸</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-envelope" style="color:#dc2626; margin-left:5px;"></i> info@arn.shop</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-map-marker-alt" style="color:#dc2626; margin-left:5px;"></i> تهران، خیابان ولیعصر</a>
        </div>
        <div style="display:flex; justify-content:center; gap:10px; margin-bottom:15px;">
            <a href="#" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-instagram"></i></a>
            <a href="#" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-telegram"></i></a>
            <a href="#" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-whatsapp"></i></a>
            <a href="#" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-facebook-f"></i></a>
        </div>
        <div style="border-top:1px solid #374151; padding-top:15px; margin-top:10px;">
            <p style="color:#9ca3af; font-size:13px;">© ۲۰۲۴ تمامی حقوق محفوظ است | ارن</p>
            <div style="display:flex; justify-content:center; gap:15px; margin-top:8px;">
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">شرایط استفاده</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">قوانین</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">حریم خصوصی</a>
            </div>
        </div>
    </div>
</div>

<div class="fixed bottom-6 left-6">
    <button class="w-14 h-14 bg-red-600 rounded-full flex items-center justify-center shadow-lg hover:bg-red-700">
        <i class="fas fa-comment-alt text-white text-xl"></i>
    </button>
</div>

</body>
</html>