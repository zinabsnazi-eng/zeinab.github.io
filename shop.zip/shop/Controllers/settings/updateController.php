<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_POST['id'] ?? 0;
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$address = $_POST['address'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$instagram = $_POST['instagram'] ?? '';
$telegram = $_POST['telegram'] ?? '';
$whatsapp = $_POST['whatsapp'] ?? '';
$facebook = $_POST['facebook'] ?? '';
$footer_text = $_POST['footer_text'] ?? '';
$logoName = $_FILES['logo']['name'] ?? '';
$logoTmp = $_FILES['logo']['tmp_name'] ?? '';
$defaultLogo = "default-logo.png";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "" && isset($id) && $id > 0) {
        
        $stmt = $conn->prepare("SELECT `logo` FROM `settings` WHERE `id` = ?");
        $stmt->execute([$id]);
        $oldLogo = $stmt->fetchColumn();
        
        if (!empty($logoName)) {
            $finalLogo = time() . '_' . $logoName;
            $uploadPath = "../../Public/setting_logo/" . $finalLogo;
            
            if (!is_dir("../../Public/setting_logo/")) {
                mkdir("../../Public/setting_logo/", 0777, true);
            }
            
            if (move_uploaded_file($logoTmp, $uploadPath)) {
                if (!empty($oldLogo) && $oldLogo != $defaultLogo && file_exists("../../Public/setting_logo/" . $oldLogo)) {
                    unlink("../../Public/setting_logo/" . $oldLogo);
                }
            }
        } else {
            $finalLogo = $oldLogo;
        }
        
        $query = "UPDATE `settings` SET 
                    `title` = ?,
                    `logo` = ?,
                    `description` = ?,
                    `address` = ?,
                    `phone` = ?,
                    `email` = ?,
                    `instagram` = ?,
                    `telegram` = ?,
                    `whatsapp` = ?,
                    `facebook` = ?,
                    `footer_text` = ?
                  WHERE `id` = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $finalLogo, $description, $address, $phone, $email, $instagram, $telegram, $whatsapp, $facebook, $footer_text, $id]);
        
        $_SESSION['done'] = "تنظیمات با موفقیت ویرایش شد ✅";
        Redirect("Admin/settings/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان فروشگاه اجباری است!";
        Redirect("Admin/settings/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/settings/index.php");
}