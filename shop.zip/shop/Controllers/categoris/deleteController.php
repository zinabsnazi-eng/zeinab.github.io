<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_GET['id'] ?? 0;

if (isset($id) && $id > 0) {
    
    $stmt = $conn->prepare("SELECT `image` FROM `categoris` WHERE `id` = ?");
    $stmt->execute([$id]);
    $image = $stmt->fetchColumn();
    
    if (!empty($image) && $image != "default-image.jpg" && file_exists("../../Public/categoris_images/" . $image)) {
        unlink("../../Public/categoris_images/" . $image);
    }
    
    $query = "DELETE FROM `categoris` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    
    $_SESSION['done'] = "دسته‌بندی با موفقیت حذف شد";
    Redirect("Admin/categoris/index.php");
    
} else {
    $_SESSION['error'] = "آیدی نامعتبر است!";
    Redirect("Admin/categoris/index.php");
}