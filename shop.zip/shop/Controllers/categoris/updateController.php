<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_POST['id'] ?? 0;
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$imageName = $_FILES['image']['name'] ?? '';
$imageTmp = $_FILES['image']['tmp_name'] ?? '';
$defaultimage = "default-image.jpg";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "" && isset($id) && $id > 0) {
        
        // دریافت عکس قبلی برای حذف
        $stmt = $conn->prepare("SELECT `image` FROM `categoris` WHERE `id` = ?");
        $stmt->execute([$id]);
        $oldImage = $stmt->fetchColumn();
        
        if (!empty($imageName)) {
            $finalimage = time() . '_' . $imageName;
            $uploadPath = "../../Public/categoris_images/" . $finalimage;
            
            if (!is_dir("../../Public/categoris_images/")) {
                mkdir("../../Public/categoris_images/", 0777, true);
            }
            
            if (move_uploaded_file($imageTmp, $uploadPath)) {
                // حذف عکس قبلی اگر default نبود
                if (!empty($oldImage) && $oldImage != $defaultimage && file_exists("../../Public/categoris_images/" . $oldImage)) {
                    unlink("../../Public/categoris_images/" . $oldImage);
                }
            }
        } else {
            $finalimage = $oldImage;
        }
        
        $query = "UPDATE `categoris` SET `title` = ? , `description` = ? , `image` = ? WHERE `id` = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $description, $finalimage, $id]);
        
        $_SESSION['done'] = "دسته‌بندی با موفقیت ویرایش شد ";
        Redirect("Admin/categoris/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان دسته‌بندی اجباری است!";
        Redirect("Admin/categoris/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/categoris/index.php");
}