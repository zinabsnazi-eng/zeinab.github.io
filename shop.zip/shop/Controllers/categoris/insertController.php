<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$imageName = $_FILES['image']['name'] ?? '';
$imageTmp = $_FILES['image']['tmp_name'] ?? '';
$defaultimage = "default-image.jpg";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "") {
        
        if (!empty($imageName)) {
            $finalimage = time() . '_' . $imageName;
            $uploadPath = "../../Public/categoris_images/" . $finalimage;
            
            if (!is_dir("../../Public/categoris_images/")) {
                mkdir("../../Public/categoris_images/", 0777, true);
            }
            
            move_uploaded_file($imageTmp, $uploadPath);
        } else {
            $finalimage = $defaultimage;
        }
        
        $query = "INSERT INTO `categoris` (`title`, `description`, `image`) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $description, $finalimage]);
        
        $_SESSION['done'] = "دسته‌بندی با موفقیت اضافه شد";
        Redirect("Admin/categoris/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان دسته‌بندی اجباری است!";
        Redirect("Admin/categoris/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/categoris/index.php");
}