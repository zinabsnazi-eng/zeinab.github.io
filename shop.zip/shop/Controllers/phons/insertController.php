<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$imageName = $_FILES['image']['name'] ?? '';
$imageTmp = $_FILES['image']['tmp_name'] ?? '';
$defaultimage = "default-image.jpg";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "") {
        
        if (!empty($imageName)) {
            $finalimage = time() . '_' . $imageName;
            $uploadPath = "../../Public/phons_images/" . $finalimage;
            
            if (!is_dir("../../Public/phons_images/")) {
                mkdir("../../Public/phons_images/", 0777, true);
            }
            
            move_uploaded_file($imageTmp, $uploadPath);
        } else {
            $finalimage = $defaultimage;
        }
        
        $query = "INSERT INTO `phons` (`title`, `description`, `image`) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $description, $finalimage]);
        
        $_SESSION['done'] = "موبایل با موفقیت اضافه شد";
        Redirect("Admin/phons/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان موبایل اجباری است!";
        Redirect("Admin/phons/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/phons/index.php");
}