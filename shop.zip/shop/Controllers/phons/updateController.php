<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_POST['id'] ?? 0;
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$imageName = $_FILES['image']['name'] ?? '';
$imageTmp = $_FILES['image']['tmp_name'] ?? '';
$defaultimage = "default-image.jpg";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "" && isset($id) && $id > 0) {
        
        $stmt = $conn->prepare("SELECT `image` FROM `phons` WHERE `id` = ?");
        $stmt->execute([$id]);
        $oldImage = $stmt->fetchColumn();
        
        if (!empty($imageName)) {
            $finalimage = time() . '_' . $imageName;
            $uploadPath = "../../Public/phons_images/" . $finalimage;
            
            if (!is_dir("../../Public/phons_images/")) {
                mkdir("../../Public/phons_images/", 0777, true);
            }
            
            if (move_uploaded_file($imageTmp, $uploadPath)) {
                if (!empty($oldImage) && $oldImage != $defaultimage && file_exists("../../Public/phons_images/" . $oldImage)) {
                    unlink("../../Public/phons_images/" . $oldImage);
                }
            }
        } else {
            $finalimage = $oldImage;
        }
        
        $query = "UPDATE `phons` SET `title` = ? , `description` = ? , `image` = ? WHERE `id` = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $description, $finalimage, $id]);
        
        $_SESSION['done'] = "موبایل با موفقیت ویرایش شد";
        Redirect("Admin/phons/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان اجباری است!";
        Redirect("Admin/phons/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/phons/index.php");
}