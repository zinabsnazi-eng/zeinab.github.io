<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_GET['id'] ?? 0;

if (isset($id) && $id > 0) {
    
    $stmt = $conn->prepare("SELECT `image` FROM `phons` WHERE `id` = ?");
    $stmt->execute([$id]);
    $image = $stmt->fetchColumn();
    
    if (!empty($image) && $image != "default-image.jpg" && file_exists("../../Public/phons_images/" . $image)) {
        unlink("../../Public/phons_images/" . $image);
    }
    
    $query = "DELETE FROM `phons` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    
    $_SESSION['done'] = "موبایل با موفقیت حذف شد";
    Redirect("Admin/phons/index.php");
    
} else {
    $_SESSION['error'] = "آیدی نامعتبر است!";
    Redirect("Admin/phons/index.php");
}