<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_POST['id'] ?? 0;
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$price = $_POST['price'] ?? 0;
$old_price = $_POST['old_price'] ?? null;
$category_id = $_POST['category_id'] ?? null;
$is_deal = $_POST['is_deal'] ?? 0;
$deal_label = $_POST['deal_label'] ?? '';
$rating = $_POST['rating'] ?? 0;
$review_count = $_POST['review_count'] ?? 0;
$imageName = $_FILES['image']['name'] ?? '';
$imageTmp = $_FILES['image']['tmp_name'] ?? '';
$defaultimage = "default-image.jpg";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($title) && $title != "" && isset($price) && $price > 0 && isset($id) && $id > 0) {
        
        // دریافت عکس قبلی
        $stmt = $conn->prepare("SELECT `image` FROM `products` WHERE `id` = ?");
        $stmt->execute([$id]);
        $oldImage = $stmt->fetchColumn();
        
        if (!empty($imageName)) {
            $finalimage = time() . '_' . $imageName;
            $uploadPath = "../../Public/products/" . $finalimage;
            
            if (!is_dir("../../Public/products/")) {
                mkdir("../../Public/products/", 0777, true);
            }
            
            if (move_uploaded_file($imageTmp, $uploadPath)) {
                // حذف عکس قبلی اگر default نبود
                if (!empty($oldImage) && $oldImage != $defaultimage && file_exists("../../Public/products/" . $oldImage)) {
                    unlink("../../Public/products/" . $oldImage);
                }
            }
        } else {
            $finalimage = $oldImage;
        }
        
        $query = "UPDATE `products` SET 
                    `title` = ?,
                    `description` = ?,
                    `price` = ?,
                    `old_price` = ?,
                    `category_id` = ?,
                    `is_deal` = ?,
                    `deal_label` = ?,
                    `rating` = ?,
                    `review_count` = ?,
                    `image` = ?
                  WHERE `id` = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$title, $description, $price, $old_price, $category_id, $is_deal, $deal_label, $rating, $review_count, $finalimage, $id]);
        
        $_SESSION['done'] = "محصول با موفقیت ویرایش شد";
        Redirect("Admin/products/index.php");
        
    } else {
        $_SESSION['error'] = "عنوان و قیمت محصول اجباری است!";
        Redirect("Admin/products/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/products/index.php");
}