<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_GET['id'] ?? 0;

if (isset($id) && $id > 0) {
    
    // دریافت نام عکس برای حذف
    $stmt = $conn->prepare("SELECT `image` FROM `products` WHERE `id` = ?");
    $stmt->execute([$id]);
    $image = $stmt->fetchColumn();
    
    // حذف عکس اگر default نبود
    if (!empty($image) && $image != "default-image.jpg" && file_exists("../../Public/products/" . $image)) {
        unlink("../../Public/products/" . $image);
    }
    
    $query = "DELETE FROM `products` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    
    $_SESSION['done'] = "محصول با موفقیت حذف شد ";
    Redirect("Admin/products/index.php");
    
} else {
    $_SESSION['error'] = "آیدی نامعتبر است!";
    Redirect("Admin/products/index.php");
}