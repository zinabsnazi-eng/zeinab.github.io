<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_GET['id'] ?? 0;

if (isset($id) && $id > 0) {
    
    // دریافت لوگو برای حذف
    $stmt = $conn->prepare("SELECT `logo` FROM `brands` WHERE `id` = ?");
    $stmt->execute([$id]);
    $logo = $stmt->fetchColumn();
    
    if (!empty($logo) && $logo != "default-brand.png" && file_exists("../../Public/brands/" . $logo)) {
        unlink("../../Public/brands/" . $logo);
    }
    
    $query = "DELETE FROM `brands` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    
    $_SESSION['done'] = "برند با موفقیت حذف شد ✅";
    Redirect("Admin/brands/index.php");
    
} else {
    $_SESSION['error'] = "آیدی نامعتبر است!";
    Redirect("Admin/brands/index.php");
}