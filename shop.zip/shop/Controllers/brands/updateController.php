<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$id = $_POST['id'] ?? 0;
$name = $_POST['name'] ?? '';
$description = $_POST['description'] ?? '';
$website = $_POST['website'] ?? '';
$is_active = $_POST['is_active'] ?? 1;
$logoName = $_FILES['logo']['name'] ?? '';
$logoTmp = $_FILES['logo']['tmp_name'] ?? '';
$defaultLogo = "default-brand.png";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($name) && $name != "" && isset($id) && $id > 0) {
        
        // دریافت لوگو قبلی
        $stmt = $conn->prepare("SELECT `logo` FROM `brands` WHERE `id` = ?");
        $stmt->execute([$id]);
        $oldLogo = $stmt->fetchColumn();
        
        if (!empty($logoName)) {
            $finalLogo = time() . '_' . $logoName;
            $uploadPath = "../../Public/brands/" . $finalLogo;
            
            if (!is_dir("../../Public/brands/")) {
                mkdir("../../Public/brands/", 0777, true);
            }
            
            if (move_uploaded_file($logoTmp, $uploadPath)) {
                if (!empty($oldLogo) && $oldLogo != $defaultLogo && file_exists("../../Public/brands/" . $oldLogo)) {
                    unlink("../../Public/brands/" . $oldLogo);
                }
            }
        } else {
            $finalLogo = $oldLogo;
        }
        
        $query = "UPDATE `brands` SET `name` = ?, `description` = ?, `website` = ?, `is_active` = ?, `logo` = ? WHERE `id` = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$name, $description, $website, $is_active, $finalLogo, $id]);
        
        $_SESSION['done'] = "برند با موفقیت ویرایش شد ✅";
        Redirect("Admin/brands/index.php");
        
    } else {
        $_SESSION['error'] = "نام برند اجباری است!";
        Redirect("Admin/brands/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/brands/index.php");
}