<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$name = $_POST['name'] ?? '';
$description = $_POST['description'] ?? '';
$website = $_POST['website'] ?? '';
$is_active = $_POST['is_active'] ?? 1;
$logoName = $_FILES['logo']['name'] ?? '';
$logoTmp = $_FILES['logo']['tmp_name'] ?? '';
$defaultLogo = "default-brand.png";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    
    if (isset($name) && $name != "") {
        
        if (!empty($logoName)) {
            $finalLogo = time() . '_' . $logoName;
            $uploadPath = "../../Public/brands/" . $finalLogo;
            
            if (!is_dir("../../Public/brands/")) {
                mkdir("../../Public/brands/", 0777, true);
            }
            
            move_uploaded_file($logoTmp, $uploadPath);
        } else {
            $finalLogo = $defaultLogo;
        }
        
        $query = "INSERT INTO `brands` (`name`, `description`, `website`, `is_active`, `logo`) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$name, $description, $website, $is_active, $finalLogo]);
        
        $_SESSION['done'] = "برند با موفقیت اضافه شد ✅";
        Redirect("Admin/brands/index.php");
        
    } else {
        $_SESSION['error'] = "نام برند اجباری است!";
        Redirect("Admin/brands/index.php");
    }
    
} else {
    $_SESSION['error'] = "دسترسی غیرمجاز";
    Redirect("Admin/brands/index.php");
}