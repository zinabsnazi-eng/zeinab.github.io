<?php
require_once "Config/conf.php";
require_once "Config/helpers.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['add']) && is_numeric($_GET['add'])) {
    $id = (int)$_GET['add'];
    
    $stmt = $conn->prepare("SELECT * FROM `products` WHERE `id` = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if ($product) {
        $item = [
            'id' => $product['id'],
            'name' => $product['title'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => 1
        ];
        
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity']++;
        } else {
            $_SESSION['cart'][$id] = $item;
        }
        
        $_SESSION['done'] = "محصول به سبد خرید اضافه شد ✅";
    }
    
    header("Location: /shop/index.php");
    exit;
}

$deals = $conn->query("SELECT * FROM `products` WHERE `is_deal` = 1 ORDER BY `id` DESC LIMIT 5")->fetchAll();
$categories = $conn->query("SELECT * FROM `categoris` ORDER BY `id` DESC")->fetchAll();
$brands = $conn->query("SELECT * FROM `brands` WHERE `is_active` = 1 ORDER BY `id` DESC LIMIT 6")->fetchAll();
$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();

if (!isset($_SESSION['city'])) {
    $_SESSION['city'] = 'تهران';
}

if (isset($_POST['city'])) {
    $_SESSION['city'] = $_POST['city'];
    header("Location: /shop/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($settings['title'] ?? 'فروشگاه ارن') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f5f5f5;color:#1a1a1a;}
        .line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
        .deal-timer{background:linear-gradient(90deg,#ff4d4d 0%,#ff8a4d 100%);}
        .deal-item{transition:all 0.3s ease;position:relative;overflow:hidden;}
        .deal-item:hover{transform:translateY(-5px);box-shadow:0 10px 40px rgba(0,0,0,0.1);}
        .deal-item .badge{position:absolute;top:10px;right:10px;background:#dc2626;color:#fff;padding:4px 12px;border-radius:6px;font-size:11px;font-weight:600;z-index:2;}
        .deal-item .badge-discount{position:absolute;top:10px;left:10px;background:#ef4444;color:#fff;padding:4px 12px;border-radius:6px;font-size:11px;font-weight:700;z-index:2;}
        .btn-cart{background:#dc2626;color:#fff;padding:6px 16px;border:none;border-radius:8px;font-size:13px;font-weight:600;transition:all 0.3s ease;cursor:pointer;display:inline-flex;align-items:center;gap:6px;width:100%;justify-content:center;text-decoration:none;}
        .btn-cart:hover{background:#b91c1c;transform:translateY(-2px);box-shadow:0 8px 25px rgba(220,38,38,0.3);color:#fff;}
        .stars{color:#fbbf24;font-size:12px;}
        .stars .empty{color:#d1d5db;}
        .old-price{text-decoration:line-through;color:#9ca3af;font-size:13px;}
        .current-price{color:#dc2626;font-weight:700;font-size:16px;}
        .product-img{width:100%;height:300px;object-fit:contain;border-radius:8px;background:#f8fafc;}
        .alert-msg{padding:14px 20px;border-radius:12px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:10px;}
        .alert-success{background:#f0fdf4;color:#166534;border-right:4px solid #22c55e;}
        .category-item{transition:all 0.3s ease;cursor:pointer;}
        .category-item:hover{transform:translateY(-5px);}
        .brand-item{transition:all 0.3s ease;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;border:2px solid #e5e7eb;border-radius:12px;background:#fff;min-height:100px;text-decoration:none;}
        .brand-item:hover{transform:translateY(-5px);border-color:#dc2626;box-shadow:0 10px 40px rgba(0,0,0,0.08);}
        .brand-item .brand-logo{max-width:100px;max-height:50px;object-fit:contain;margin-bottom:8px;}
        .brand-item .brand-name{font-size:13px;font-weight:600;color:#1a1a1a;text-align:center;}
        .brand-item .brand-count{font-size:11px;color:#6b7280;margin-top:2px;}
        .brand-item .brand-icon{font-size:2.5rem;color:#dc2626;margin-bottom:5px;}
        .img-wrapper{height:300px;overflow:hidden;border-radius:8px;background:#f8fafc;display:flex;align-items:center;justify-content:center;}
        .location-dropdown{position:relative;display:inline-block;cursor:pointer;}
        .location-dropdown .dropdown-menu{display:none;position:absolute;top:100%;right:0;background:#fff;min-width:200px;max-height:300px;overflow-y:auto;box-shadow:0 10px 40px rgba(0,0,0,0.15);border-radius:12px;padding:8px 0;z-index:1000;border:1px solid #e5e7eb;margin-top:5px;}
        .location-dropdown:hover .dropdown-menu{display:block;}
        .location-dropdown .dropdown-item{padding:10px 20px;color:#1a1a1a;text-decoration:none;display:block;font-size:14px;transition:all 0.2s;border:none;background:none;width:100%;text-align:right;cursor:pointer;font-family:inherit;}
        .location-dropdown .dropdown-item:hover{background:#f3f4f6;color:#dc2626;}
        .location-dropdown .dropdown-item.active{background:#dc2626;color:#fff;}
        .location-dropdown .dropdown-item i{margin-left:10px;color:#dc2626;width:18px;}
        .location-btn{background:none;border:none;color:#2563eb;font-weight:600;font-size:14px;cursor:pointer;display:flex;align-items:center;gap:6px;font-family:inherit;padding:4px 8px;border-radius:8px;transition:all 0.2s;}
        .location-btn:hover{background:#eff6ff;}
        .location-btn i{color:#2563eb;font-size:16px;}
        .location-current{color:#1a1a1a;font-weight:600;margin-left:4px;}
        .location-label{color:#6b7280;font-size:14px;}
        .search-form{position:relative;width:100%;}
        .search-form input{width:100%;padding:10px 16px;padding-left:50px;border:1px solid #e5e7eb;border-radius:12px;font-size:14px;transition:all 0.3s;background:#fafafa;}
        .search-form input:focus{border-color:#dc2626;outline:none;box-shadow:0 0 0 4px rgba(220,38,38,0.1);background:#fff;}
        .search-form button{position:absolute;left:0;top:0;height:100%;background:#dc2626;color:#fff;border:none;padding:0 18px;border-radius:0 12px 12px 0;cursor:pointer;transition:0.3s;}
        .search-form button:hover{background:#b91c1c;}
        .header-link{color:#6b7280;transition:0.3s;font-size:14px;}
        .header-link:hover{color:#dc2626;}
    </style>
</head>
<body class="bg-gray-50 font-sans">

<header class="bg-white shadow-sm sticky top-0 z-50">
    <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <a href="/shop/index.php" class="text-2xl font-bold text-red-600">
                    <?php if (!empty($settings['logo']) && $settings['logo'] != "default-logo.png" && file_exists("Public/setting_logo/" . $settings['logo'])): ?>
                        <img src="<?= Assets("setting_logo/" . $settings['logo']) ?>" alt="<?= htmlspecialchars($settings['title']) ?>" style="height:35px;">
                    <?php else: ?>
                        <?= htmlspecialchars($settings['title'] ?? 'ارن') ?>
                    <?php endif; ?>
                </a>
                <span class="mr-2 text-xs text-gray-500 hidden sm:inline"><?= htmlspecialchars($settings['description'] ?? 'خرید هوشمند، زندگی آسان') ?></span>
            </div>

            <div class="flex-1 mx-4 max-w-xl hidden md:block">
                <form action="/shop/search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="جستجوی محصول..." required>
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div class="flex items-center space-x-4 space-x-reverse">
                <a href="/shop/cart.php" class="text-gray-700 hover:text-red-600 relative">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span class="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"><?php $c=0;if(isset($_SESSION['cart'])){foreach($_SESSION['cart'] as $item){$c+=$item['quantity'];}}echo $c;?></span>
                </a>
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'admin'): ?>
                    <a href="/shop/Admin/index.php" class="text-gray-700 hover:text-red-600"><i class="fas fa-tachometer-alt text-xl"></i></a>
                    <a href="/shop/logout.php" class="text-gray-700 hover:text-red-600"><i class="fas fa-sign-out-alt text-xl"></i></a>
                <?php else: ?>
                    <a href="/shop/login.php" class="text-gray-700 hover:text-red-600"><i class="fas fa-user text-xl"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<div class="bg-blue-50 py-2 px-4 text-sm border-b border-blue-100">
    <div class="container mx-auto flex items-center justify-between flex-wrap gap-2">
        <div class="flex items-center">
            <i class="fas fa-map-marker-alt text-blue-600 ml-2"></i>
            <span class="location-label">آدرس تحویل:</span>
            <div class="location-dropdown mr-2">
                <button class="location-btn">
                    <i class="fas fa-chevron-down"></i>
                    <span class="location-current"><?= htmlspecialchars($_SESSION['city']) ?></span>
                </button>
                <div class="dropdown-menu">
                    <form method="POST" action="">
                        <?php 
                        $cities = ['تهران', 'مشهد', 'اصفهان', 'شیراز', 'تبریز', 'کرج', 'قم', 'اهواز', 'کرمانشاه', 'رشت', 'زاهدان', 'ارومیه', 'یزد', 'همدان', 'کرمان', 'اراک', 'اسلامشهر', 'قزوین', 'زنجان', 'سنندج', 'خرم‌آباد', 'بندرعباس', 'بوشهر', 'ساری', 'بابل', 'آمل', 'بیرجند', 'گرگان', 'شاهرود', 'سمنان'];
                        foreach ($cities as $city): 
                        ?>
                            <button type="submit" name="city" value="<?= $city ?>" class="dropdown-item <?= ($_SESSION['city'] == $city) ? 'active' : '' ?>">
                                <i class="fas fa-map-pin"></i> <?= $city ?>
                            </button>
                        <?php endforeach; ?>
                    </form>
                </div>
            </div>
        </div>
        <div class="flex items-center gap-4">
            <a href="/shop/index.php" class="header-link"><i class="fas fa-home ml-1"></i> صفحه اصلی</a>
            <a href="/shop/search.php" class="header-link"><i class="fas fa-search ml-1"></i> جستجو</a>
            <a href="/shop/cart.php" class="header-link"><i class="fas fa-shopping-cart ml-1"></i> سبد خرید</a>
        </div>
    </div>
</div>

<main class="container mx-auto px-4 py-6">

    <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
        <div class="alert-msg alert-success" style="max-width:600px; margin:0 auto 20px auto;">
            <i class="fas fa-check-circle"></i>
            <?= $_SESSION['done'] ?>
            <?php $_SESSION['done'] = ""; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <h2 class="text-lg font-semibold mb-4">دسته‌بندی</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            <?php 
            $icons = ['fas fa-mobile-alt','fas fa-headphones','fas fa-charging-station','fas fa-battery-three-quarters','fas fa-shield-alt','fas fa-clock','fas fa-microphone','fas fa-camera'];
            $colors = ['blue','green','purple','yellow','red','indigo','pink','orange'];
            $i = 0;
            foreach ($categories as $category): 
            ?>
                <a href="/shop/category.php?id=<?= $category['id'] ?>" class="category-item flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-all duration-200 hover:scale-105">
                    <div class="w-12 h-12 bg-<?= $colors[$i % count($colors)] ?>-100 rounded-full flex items-center justify-center mb-2">
                        <i class="<?= $icons[$i % count($icons)] ?> text-<?= $colors[$i % count($colors)] ?>-600 text-xl"></i>
                    </div>
                    <span class="text-xs text-center"><?= htmlspecialchars($category['title']) ?></span>
                </a>
            <?php $i++; endforeach; ?>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center">
                <h2 class="text-lg font-semibold ml-4">پیشنهادات شگفت‌انگیز</h2>
                <div class="deal-timer flex items-center px-3 py-1 rounded-md text-white text-sm">
                    <i class="fas fa-clock ml-2"></i>
                    <span class="font-bold" id="timerDisplay">۰۳:۲۲:۳۴</span>
                </div>
            </div>
            <a href="/shop/search.php" class="text-sm text-red-600 hover:underline">مشاهده همه</a>
        </div>

        <?php if (count($deals) > 0): ?>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                <?php foreach ($deals as $product): ?>
                    <div class="deal-item border border-gray-200 rounded-lg p-3 bg-white">
                        <div class="img-wrapper">
                            <?php if (!empty($product['image']) && $product['image'] != "default-image.jpg" && file_exists("Public/products/" . $product['image'])): ?>
                                <img class="product-img" src="<?= Assets("products/" . $product['image']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
                            <?php else: ?>
                                <img class="product-img" src="<?= Assets("products/default-image.jpg") ?>" alt="پیش‌فرض">
                            <?php endif; ?>
                            <?php if (!empty($product['deal_label'])): ?>
                                <span class="badge"><?= htmlspecialchars($product['deal_label']) ?></span>
                            <?php endif; ?>
                            <?php if (!empty($product['old_price']) && $product['old_price'] > $product['price']): ?>
                                <?php $discount = round((($product['old_price'] - $product['price']) / $product['old_price']) * 100); ?>
                                <span class="badge-discount"><?= $discount ?>%</span>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-sm font-medium mt-2 line-clamp-2" style="height:40px;"><?= htmlspecialchars($product['title']) ?></h3>
                        <div class="flex items-center mt-1">
                            <?php if (!empty($product['old_price'])): ?>
                                <span class="old-price ml-2"><?= number_format($product['old_price']) ?> تومان</span>
                            <?php endif; ?>
                            <span class="current-price"><?= number_format($product['price']) ?> تومان</span>
                        </div>
                        <div class="flex items-center mt-2">
                            <div class="stars">
                                <?php $rating = round($product['rating'] ?? 0); for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $rating): ?><i class="fas fa-star"></i><?php else: ?><i class="fas fa-star empty"></i><?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <span class="text-xs text-gray-500 mr-1">(<?= $product['review_count'] ?? 0 ?>)</span>
                        </div>
                        <a href="/shop/index.php?add=<?= $product['id'] ?>" class="btn-cart mt-2">
                            <i class="fas fa-cart-plus"></i>
                            افزودن به سبد
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-box-open text-4xl text-gray-300 mb-3"></i>
                <p class="text-gray-500">محصول ویژه‌ای یافت نشد</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold">برندهای محبوب</h2>
            <a href="/shop/search.php" class="text-sm text-red-600 hover:underline">مشاهده همه</a>
        </div>
        <?php if (count($brands) > 0): ?>
            <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <?php foreach ($brands as $brand): ?>
                    <a href="/shop/search.php?q=<?= urlencode($brand['name']) ?>" class="brand-item">
                        <?php if (!empty($brand['logo']) && file_exists("Public/brands/" . $brand['logo'])): ?>
                            <img class="brand-logo" src="<?= Assets("brands/" . $brand['logo']) ?>" alt="<?= htmlspecialchars($brand['name']) ?>">
                        <?php else: ?>
                            <div class="brand-icon"><i class="fas fa-building"></i></div>
                        <?php endif; ?>
                        <span class="brand-name"><?= htmlspecialchars($brand['name']) ?></span>
                        <?php $stmt = $conn->prepare("SELECT COUNT(*) FROM `products` WHERE `brand_id` = ?"); $stmt->execute([$brand['id']]); $count = $stmt->fetchColumn(); ?>
                        <span class="brand-count"><?= $count ?> محصول</span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fab fa-apple"></i></div><span class="brand-name">اپل</span><span class="brand-count">۰ محصول</span></a>
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fab fa-android"></i></div><span class="brand-name">سامسونگ</span><span class="brand-count">۰ محصول</span></a>
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fas fa-microchip"></i></div><span class="brand-name">شیائومی</span><span class="brand-count">۰ محصول</span></a>
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fas fa-headphones"></i></div><span class="brand-name">سونی</span><span class="brand-count">۰ محصول</span></a>
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fas fa-gamepad"></i></div><span class="brand-name">ریزر</span><span class="brand-count">۰ محصول</span></a>
                <a href="#" class="brand-item"><div class="brand-icon"><i class="fas fa-music"></i></div><span class="brand-name">بیتس</span><span class="brand-count">۰ محصول</span></a>
            </div>
        <?php endif; ?>
    </div>

</main>

<!-- =============== FOOTER =============== -->
<div style="background:#1a1a1a; color:white; padding:30px 20px; margin-top:30px; text-align:center; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
    <div style="max-width:1200px; margin:0 auto;">
        <h4 style="font-size:22px; font-weight:700; margin-bottom:10px; color:#fff;">
            <?php if (!empty($settings['logo']) && $settings['logo'] != "default-logo.png" && file_exists("Public/setting_logo/" . $settings['logo'])): ?>
                <img src="<?= Assets("setting_logo/" . $settings['logo']) ?>" alt="<?= htmlspecialchars($settings['title']) ?>" style="height:35px;">
            <?php else: ?>
                <?= htmlspecialchars($settings['title'] ?? 'ارن') ?>
            <?php endif; ?>
        </h4>
        <p style="color:#9ca3af; font-size:14px; margin-bottom:15px;"><?= htmlspecialchars($settings['description'] ?? 'بهترین فروشگاه آنلاین با بهترین قیمت‌ها') ?></p>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="/shop/index.php" style="color:#9ca3af; text-decoration:none; font-size:14px;">صفحه اصلی</a>
            <a href="/shop/search.php" style="color:#9ca3af; text-decoration:none; font-size:14px;">جستجو</a>
            <a href="/shop/cart.php" style="color:#9ca3af; text-decoration:none; font-size:14px;">سبد خرید</a>
            <a href="/shop/login.php" style="color:#9ca3af; text-decoration:none; font-size:14px;">ورود</a>
        </div>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">درباره ما</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">تماس با ما</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">حریم خصوصی</a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;">شرایط استفاده</a>
        </div>
        <div style="display:flex; justify-content:center; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-phone" style="color:#dc2626; margin-left:5px;"></i> <?= htmlspecialchars($settings['phone'] ?? '۰۲۱-۱۲۳۴۵۶۷۸') ?></a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-envelope" style="color:#dc2626; margin-left:5px;"></i> <?= htmlspecialchars($settings['email'] ?? 'info@arn.shop') ?></a>
            <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px;"><i class="fas fa-map-marker-alt" style="color:#dc2626; margin-left:5px;"></i> <?= htmlspecialchars($settings['address'] ?? 'تهران، خیابان ولیعصر') ?></a>
        </div>
        <div style="display:flex; justify-content:center; gap:10px; margin-bottom:15px;">
            <?php if (!empty($settings['instagram'])): ?>
                <a href="<?= htmlspecialchars($settings['instagram']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-instagram"></i></a>
            <?php endif; ?>
            <?php if (!empty($settings['telegram'])): ?>
                <a href="<?= htmlspecialchars($settings['telegram']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-telegram"></i></a>
            <?php endif; ?>
            <?php if (!empty($settings['whatsapp'])): ?>
                <a href="<?= htmlspecialchars($settings['whatsapp']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-whatsapp"></i></a>
            <?php endif; ?>
            <?php if (!empty($settings['facebook'])): ?>
                <a href="<?= htmlspecialchars($settings['facebook']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-facebook-f"></i></a>
            <?php endif; ?>
        </div>
        <div style="border-top:1px solid #374151; padding-top:15px; margin-top:10px;">
            <p style="color:#9ca3af; font-size:13px;"><?= htmlspecialchars($settings['footer_text'] ?? '© ۲۰۲۴ تمامی حقوق محفوظ است | ارن') ?></p>
            <div style="display:flex; justify-content:center; gap:15px; margin-top:8px;">
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">شرایط استفاده</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">قوانین</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:12px;">حریم خصوصی</a>
            </div>
        </div>
    </div>
</div>

<div class="fixed bottom-6 left-6">
    <button class="w-14 h-14 bg-red-600 rounded-full flex items-center justify-center shadow-lg hover:bg-red-700">
        <i class="fas fa-comment-alt text-white text-xl"></i>
    </button>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        let t = 3 * 3600 + 22 * 60 + 34;
        const d = document.getElementById('timerDisplay');
        setInterval(function() {
            if (t <= 0) t = 3 * 3600 + 22 * 60 + 34;
            const h = Math.floor(t / 3600);
            const m = Math.floor((t % 3600) / 60);
            const s = t % 60;
            d.textContent = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
            t--;
        }, 1000);
    });
</script>

</body>
</html>