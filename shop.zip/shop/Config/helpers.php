<?php
@session_start();
define('BASE_URL', "http://localhost/shop");

function Assets($url){
    return BASE_URL . "/Public/" . trim($url, " /");
}

function Url($url){
    return BASE_URL . "/" . trim($url, " /");
}

function Redirect($url){
    header("location: " . BASE_URL . "/" . trim($url, " /"));
    exit();
}

function dd($data){
    echo "<pre>";
    var_dump($data);
    exit();
}
?>