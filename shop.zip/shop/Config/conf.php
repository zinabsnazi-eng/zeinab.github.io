<?php
session_start();
require "db.php";
require "helpers.php";
error_reporting (-1);
ini_set("display_errors", 0);