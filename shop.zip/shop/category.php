<?php
require_once "Config/conf.php";
require_once "Config/helpers.php";

// شروع سشن برای سبد خرید
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// دریافت ID دسته‌بندی از URL
$category_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($category_id <= 0) {
    header("Location: /shop/index.php");
    exit;
}

// دریافت اطلاعات دسته‌بندی
$stmt = $conn->prepare("SELECT * FROM `categoris` WHERE `id` = ?");
$stmt->execute([$category_id]);
$category = $stmt->fetch();

if (!$category) {
    header("Location: /shop/index.php");
    exit;
}

// دریافت محصولات این دسته‌بندی
$stmt = $conn->prepare("SELECT * FROM `products` WHERE `category_id` = ? ORDER BY `id` DESC");
$stmt->execute([$category_id]);
$products = $stmt->fetchAll();

// اضافه کردن به سبد خرید
if (isset($_GET['add']) && is_numeric($_GET['add'])) {
    $id = (int)$_GET['add'];
    
    $stmt = $conn->prepare("SELECT * FROM `products` WHERE `id` = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if ($product) {
        $item = [
            'id' => $product['id'],
            'name' => $product['title'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => 1
        ];
        
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity']++;
        } else {
            $_SESSION['cart'][$id] = $item;
        }
        
        $_SESSION['done'] = "محصول به سبد خرید اضافه شد ✅";
    }
    
    header("Location: /shop/category.php?id=" . $category_id);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($category['title']) ?> · ارن</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .product-item {
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .product-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
        }
        .product-item .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .product-item .product-image:hover {
            transform: scale(1.05);
        }
        .btn-add-cart {
            background: #dc2626;
            color: white;
            padding: 6px 16px;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: 100%;
            justify-content: center;
            text-decoration: none;
        }
        .btn-add-cart:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(220, 38, 38, 0.3);
            color: white;
        }
        .btn-add-cart i {
            font-size: 14px;
        }
        .stars {
            color: #fbbf24;
            font-size: 12px;
        }
        .stars .empty {
            color: #d1d5db;
        }
        .old-price {
            text-decoration: line-through;
            color: #9ca3af;
            font-size: 13px;
        }
        .current-price {
            color: #dc2626;
            font-weight: 700;
            font-size: 16px;
        }
        .deal-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #dc2626;
            color: white;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            z-index: 2;
        }
        .deal-badge-discount {
            position: absolute;
            top: 10px;
            left: 10px;
            background: #ef4444;
            color: white;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            z-index: 2;
        }
        .alert-custom {
            padding: 14px 20px;
            border-radius: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success-custom {
            background: #f0fdf4;
            color: #166534;
            border-right: 4px solid #22c55e;
        }
        .alert-success-custom i {
            color: #22c55e;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        .empty-state i {
            font-size: 4rem;
            color: #dc2626;
            margin-bottom: 15px;
        }
        .empty-state h3 {
            font-size: 1.3rem;
            color: #1a1a1a;
            margin-bottom: 8px;
        }
        .empty-state p {
            color: #6b7280;
        }
        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 20px;
        }
        .breadcrumb a {
            color: #dc2626;
            text-decoration: none;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        .breadcrumb .separator {
            color: #d1d5db;
        }
        .breadcrumb .current {
            color: #1a1a1a;
            font-weight: 600;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans">

<?php require_once "Admin/layouts/header.php"; ?>

<!-- بنر موقعیت -->
<div class="bg-blue-50 py-2 px-4 text-sm">
    <div class="container mx-auto flex items-center justify-between">
        <div class="flex items-center">
            <i class="fas fa-map-marker-alt text-blue-600 ml-2"></i>
            <span>آدرس تحویل: </span>
            <button class="mr-2 text-blue-600 font-medium hover:underline">تعیین موقعیت</button>
        </div>
        <button class="text-blue-600 hover:underline">چرا موقعیت خود را انتخاب کنم؟</button>
    </div>
</div>

<!-- محتوای اصلی -->
<main class="container mx-auto px-4 py-6">

    <!-- پیام موفقیت -->
    <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
        <div class="alert-custom alert-success-custom" style="max-width:600px; margin:0 auto 20px auto;">
            <i class="fas fa-check-circle"></i>
            <?= $_SESSION['done'] ?>
            <?php $_SESSION['done'] = ""; ?>
        </div>
    <?php endif; ?>

    <!-- مسیر راهنما (Breadcrumb) -->
    <div class="breadcrumb">
        <a href="/shop/index.php">خانه</a>
        <span class="separator">/</span>
        <span class="current"><?= htmlspecialchars($category['title']) ?></span>
    </div>

    <!-- عنوان دسته‌بندی -->
    <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($category['title']) ?></h1>
                <?php if (!empty($category['description'])): ?>
                    <p class="text-gray-500 text-sm mt-1"><?= htmlspecialchars($category['description']) ?></p>
                <?php endif; ?>
            </div>
            <div class="text-sm text-gray-500">
                <i class="fas fa-box"></i>
                <?= count($products) ?> محصول
            </div>
        </div>
    </div>

    <!-- محصولات دسته‌بندی -->
    <div class="bg-white rounded-lg shadow-sm p-4">
        
        <?php if (count($products) > 0): ?>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php foreach ($products as $product): ?>
                    <div class="product-item border border-gray-200 rounded-lg p-3 bg-white">
                        <div class="relative">
                            <?php if (!empty($product['image']) && $product['image'] != "default-image.jpg" && file_exists("Public/products/" . $product['image'])): ?>
                                <img class="product-image" src="<?= Assets("products/" . $product['image']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
                            <?php else: ?>
                                <img class="product-image" src="<?= Assets("products/default-image.jpg") ?>" alt="پیش‌فرض">
                            <?php endif; ?>
                            
                            <?php if (!empty($product['deal_label']) && $product['is_deal'] == 1): ?>
                                <span class="deal-badge"><?= htmlspecialchars($product['deal_label']) ?></span>
                            <?php endif; ?>
                            
                            <?php if (!empty($product['old_price']) && $product['old_price'] > $product['price']): ?>
                                <?php 
                                    $discount = round((($product['old_price'] - $product['price']) / $product['old_price']) * 100);
                                ?>
                                <span class="deal-badge-discount"><?= $discount ?>% تخفیف</span>
                            <?php endif; ?>
                        </div>
                        
                        <h3 class="text-sm font-medium mt-2 line-clamp-2"><?= htmlspecialchars($product['title']) ?></h3>
                        
                        <div class="flex items-center mt-1">
                            <?php if (!empty($product['old_price'])): ?>
                                <span class="old-price ml-2"><?= number_format($product['old_price']) ?> تومان</span>
                            <?php endif; ?>
                            <span class="current-price"><?= number_format($product['price']) ?> تومان</span>
                        </div>
                        
                        <div class="flex items-center mt-2">
                            <div class="stars">
                                <?php 
                                    $rating = round($product['rating'] ?? 0);
                                    for ($i = 1; $i <= 5; $i++): 
                                ?>
                                    <?php if ($i <= $rating): ?>
                                        <i class="fas fa-star"></i>
                                    <?php else: ?>
                                        <i class="fas fa-star empty"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <span class="text-xs text-gray-500 mr-1">(<?= $product['review_count'] ?? 0 ?>)</span>
                        </div>
                        
                        <a href="/shop/category.php?id=<?= $category_id ?>&add=<?= $product['id'] ?>" class="btn-add-cart mt-2">
                            <i class="fas fa-cart-plus"></i>
                            افزودن به سبد
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <h3>هیچ محصولی در این دسته‌بندی یافت نشد!</h3>
                <p>به زودی محصولات جدید به این دسته‌بندی اضافه خواهند شد.</p>
                <a href="/shop/index.php" class="inline-block mt-4 bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-all">
                    <i class="fas fa-arrow-right"></i>
                    بازگشت به صفحه اصلی
                </a>
            </div>
        <?php endif; ?>
    </div>

</main>

<!-- فوتر -->
<?php require_once "Admin/layouts/footer.php"; ?>

<!-- دکمه چت -->
<div class="fixed bottom-6 left-6">
    <button class="w-14 h-14 bg-red-600 rounded-full flex items-center justify-center shadow-lg hover:bg-red-700">
        <i class="fas fa-comment-alt text-white text-xl"></i>
    </button>
</div>

</body>
</html>