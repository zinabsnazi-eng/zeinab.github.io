<?php
require_once "Config/conf.php";
require_once "Config/helpers.php";


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $id = (int)$_GET['remove'];
    if (isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
        $_SESSION['done'] = "محصول با موفقیت از سبد خرید حذف شد";
    }
    header("Location: /shop/cart.php");
    exit;
}

if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    $_SESSION['done'] = "سبد خرید با موفقیت خالی شد";
    header("Location: /shop/cart.php");
    exit;
}

if (isset($_POST['update']) && isset($_POST['quantities'])) {
    foreach ($_POST['quantities'] as $id => $qty) {
        $id = (int)$id;
        $qty = (int)$qty;
        if ($qty > 0) {
            $_SESSION['cart'][$id]['quantity'] = $qty;
        } else {
            unset($_SESSION['cart'][$id]);
        }
    }
    $_SESSION['done'] = "سبد خرید با موفقیت به‌روزرسانی شد";
    header("Location: /shop/cart.php");
    exit;
}

// محاسبه جمع کل
$totalPrice = 0;
$totalItems = 0;
foreach ($_SESSION['cart'] as $item) {
    $totalPrice += $item['price'] * $item['quantity'];
    $totalItems += $item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبد خرید · ارن</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #1a1a1a;
            line-height: 1.6;
        }

        .container-custom {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 3px solid #dc2626;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            color: #dc2626;
            font-size: 2.2rem;
        }

        .header-badge {
            font-size: 14px;
            color: #6b7280;
            background: #f3f4f6;
            padding: 8px 18px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .header-badge i {
            color: #dc2626;
        }

        .card-custom {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            padding: 2rem;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            margin-bottom: 2rem;
        }

        .card-custom:hover {
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.08);
        }

        .card-custom .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            padding-bottom: 0.8rem;
            border-bottom: 2px solid #f3f4f6;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-custom .card-title i {
            color: #dc2626;
        }

        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-custom {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 14px;
            min-width: 700px;
        }

        .table-custom thead th {
            background: #1a1a1a;
            color: #ffffff;
            padding: 16px 20px;
            font-weight: 600;
            text-align: center;
            border: none;
            white-space: nowrap;
            font-size: 13px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .table-custom thead th:first-child {
            border-radius: 12px 0 0 0;
        }

        .table-custom thead th:last-child {
            border-radius: 0 12px 0 0;
        }

        .table-custom tbody tr {
            background: #ffffff;
            transition: all 0.2s ease;
            border-bottom: 1px solid #f3f4f6;
        }

        .table-custom tbody tr:hover {
            background: #fafafa;
        }

        .table-custom tbody td {
            padding: 16px 20px;
            text-align: center;
            color: #1a1a1a;
            border: none;
            vertical-align: middle;
            font-size: 14px;
        }

        .table-custom tbody td:first-child {
            font-weight: 600;
            color: #dc2626;
        }

        .table-img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            object-fit: cover;
            border: 2px solid #e5e7eb;
            transition: all 0.3s ease;
        }

        .table-img:hover {
            transform: scale(1.8);
            border-color: #dc2626;
            box-shadow: 0 8px 30px rgba(220, 38, 38, 0.2);
            z-index: 10;
            position: relative;
        }

        .quantity-input {
            width: 60px;
            padding: 8px 10px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            text-align: center;
            background: #fafafa;
            transition: all 0.3s ease;
        }

        .quantity-input:focus {
            border-color: #dc2626;
            outline: none;
            box-shadow: 0 0 0 4px rgba(220, 38, 38, 0.1);
            background: #ffffff;
        }

        .btn-remove {
            background: #ef4444;
            color: #ffffff;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-remove:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
            color: #ffffff;
        }

        .btn-remove i {
            font-size: 12px;
        }

        .btn-success-custom {
            background: #dc2626;
            color: #ffffff;
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-success-custom:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(220, 38, 38, 0.3);
            color: #ffffff;
        }

        .btn-secondary-custom {
            background: #f3f4f6;
            color: #1a1a1a;
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-secondary-custom:hover {
            background: #e5e7eb;
        }

        .btn-danger-custom {
            background: #ef4444;
            color: #ffffff;
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-danger-custom:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
            color: #ffffff;
        }

        .alert-custom {
            padding: 14px 20px;
            border-radius: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success-custom {
            background: #f0fdf4;
            color: #166534;
            border-right: 4px solid #22c55e;
        }

        .alert-success-custom i {
            color: #22c55e;
        }

        .alert-danger-custom {
            background: #fef2f2;
            color: #991b1b;
            border-right: 4px solid #ef4444;
        }

        .alert-danger-custom i {
            color: #ef4444;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 5rem;
            color: #dc2626;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            font-size: 1.5rem;
            color: #1a1a1a;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #6b7280;
            font-size: 16px;
        }

        .empty-state .btn-success-custom {
            margin-top: 20px;
        }

        .cart-summary {
            background: #fafafa;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #e5e7eb;
        }

        .cart-summary .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
        }

        .cart-summary .summary-row:last-child {
            border-bottom: none;
            font-size: 1.2rem;
            font-weight: 700;
            color: #dc2626;
        }

        .cart-summary .summary-label {
            color: #6b7280;
        }

        .cart-summary .summary-value {
            font-weight: 600;
        }

        .flex-buttons {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            .container-custom {
                padding: 1rem;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .page-title {
                font-size: 1.6rem;
            }

            .card-custom {
                padding: 1.2rem;
            }

            .table-custom {
                font-size: 12px;
                min-width: 600px;
            }

            .table-custom thead th,
            .table-custom tbody td {
                padding: 10px 12px;
                font-size: 12px;
                white-space: nowrap;
            }

            .table-img {
                width: 32px;
                height: 32px;
            }

            .quantity-input {
                width: 50px;
                padding: 6px 8px;
                font-size: 12px;
            }

            .btn-remove {
                padding: 6px 12px;
                font-size: 11px;
            }

            .flex-buttons {
                flex-direction: column;
            }

            .flex-buttons .btn-success-custom,
            .flex-buttons .btn-danger-custom,
            .flex-buttons .btn-secondary-custom {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .container-custom {
                padding: 0.8rem;
            }

            .page-title {
                font-size: 1.3rem;
            }

            .card-custom {
                padding: 0.8rem;
            }

            .table-custom {
                font-size: 10px;
                min-width: 500px;
            }

            .table-custom thead th,
            .table-custom tbody td {
                padding: 6px 8px;
                font-size: 10px;
            }

            .table-img {
                width: 25px;
                height: 25px;
            }

            .quantity-input {
                width: 40px;
                padding: 4px 6px;
                font-size: 10px;
            }

            .btn-remove {
                padding: 4px 8px;
                font-size: 9px;
                border-radius: 6px;
            }
        }
    </style>
</head>
<body>

<?php require_once "Admin/layouts/header.php"; ?>

<div class="container-custom">

    <div class="page-header">
        <h1 class="page-title">
            <i class="fas fa-shopping-cart"></i>
            سبد خرید
        </h1>
        <div class="header-badge">
            <i class="fas fa-box"></i>
            <?= $totalItems ?> محصول
        </div>
    </div>

    <div class="card-custom">
        <div class="card-title">
            <i class="fas fa-list"></i>
            محصولات سبد خرید
        </div>

        <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
            <div class="alert-custom alert-success-custom">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['done'] ?>
                <?php $_SESSION['done'] = ""; ?>
            </div>
        <?php elseif (!empty($_SESSION['error']) && isset($_SESSION['error'])): ?>
            <div class="alert-custom alert-danger-custom">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error'] ?>
                <?php $_SESSION['error'] = ""; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['cart'])): ?>
            <form method="POST" action="">
                <div class="table-wrapper">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>تصویر</th>
                                <th>نام محصول</th>
                                <th>قیمت</th>
                                <th>تعداد</th>
                                <th>جمع</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $row = 1; ?>
                            <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                                <tr>
                                    <td><?= $row++ ?></td>
                                    <td>
                                        <?php if (!empty($item['image']) && file_exists("Public/products/" . $item['image'])): ?>
                                            <img class="table-img" src="<?= Assets("products/" . $item['image']) ?>" alt="<?= $item['name'] ?>">
                                        <?php else: ?>
                                            <img class="table-img" src="<?= Assets("products/default-image.jpg") ?>" alt="پیش‌فرض">
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td><?= number_format($item['price']) ?> تومان</td>
                                    <td>
                                        <input type="number" name="quantities[<?= $id ?>]" value="<?= $item['quantity'] ?>" min="1" max="99" class="quantity-input">
                                    </td>
                                    <td><?= number_format($item['price'] * $item['quantity']) ?> تومان</td>
                                    <td>
                                        <a href="/shop/cart.php?remove=<?= $id ?>" class="btn-remove" onclick="return confirm('آیا از حذف این محصول مطمئن هستید؟')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="flex-buttons">
                    <button type="submit" name="update" class="btn-success-custom">
                        <i class="fas fa-sync"></i>
                        به‌روزرسانی سبد
                    </button>
                    <a href="/shop/cart.php?clear=1" class="btn-danger-custom" onclick="return confirm('آیا از خالی کردن سبد خرید مطمئن هستید؟')">
                        <i class="fas fa-trash"></i>
                        خالی کردن سبد
                    </a>
                    <a href="/shop/index.php" class="btn-secondary-custom">
                        <i class="fas fa-arrow-right"></i>
                        ادامه خرید
                    </a>
                </div>
            </form>

            <!-- جمع کل -->
            <div class="cart-summary" style="margin-top: 30px;">
                <div class="summary-row">
                    <span class="summary-label">تعداد محصولات:</span>
                    <span class="summary-value"><?= $totalItems ?></span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">جمع کل:</span>
                    <span class="summary-value"><?= number_format($totalPrice) ?> تومان</span>
                </div>
                <div class="summary-row" style="font-size:1.3rem;">
                    <span class="summary-label">قابل پرداخت:</span>
                    <span class="summary-value" style="color:#dc2626;"><?= number_format($totalPrice) ?> تومان</span>
                </div>
                <button class="btn-success-custom" style="width:100%; margin-top:15px; justify-content:center;">
                    <i class="fas fa-check"></i>
                    نهایی‌سازی خرید
                </button>
            </div>

        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-shopping-basket"></i>
                <h3>سبد خرید شما خالی است!</h3>
                <p>برای خرید، به صفحه محصولات بروید و محصول مورد نظر را به سبد اضافه کنید.</p>
                <a href="/shop/index.php" class="btn-success-custom">
                    <i class="fas fa-arrow-right"></i>
                    شروع خرید
                </a>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php require_once "Admin/layouts/footer.php"; ?>

</body>
</html>