<?php
require_once "../Config/conf.php";
require_once "../Config/helpers.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// محافظت از صفحه ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: /shop/login.php");
    exit;
}

$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();

$productsCount = $conn->query("SELECT COUNT(*) FROM `products`")->fetchColumn();
$categoriesCount = $conn->query("SELECT COUNT(*) FROM `categoris`")->fetchColumn();
$brandsCount = $conn->query("SELECT COUNT(*) FROM `brands`")->fetchColumn();
$ordersCount = 0;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت · ارن</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f1f5f9;color:#1a1a1a;}
        .container-custom{max-width:1200px;margin:0 auto;padding:2rem;}
        .page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:2.5rem;padding-bottom:1.5rem;border-bottom:3px solid #dc2626;flex-wrap:wrap;gap:15px;}
        .page-title{font-size:2.5rem;font-weight:700;color:#1a1a1a;display:flex;align-items:center;gap:12px;}
        .page-title i{color:#dc2626;font-size:2.2rem;}
        .header-badge{font-size:14px;color:#6b7280;background:#f3f4f6;padding:8px 18px;border-radius:10px;display:flex;align-items:center;gap:8px;}
        .header-badge i{color:#dc2626;}
        .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px;}
        .stat-card{background:#fff;border-radius:16px;padding:20px;box-shadow:0 2px 10px rgba(0,0,0,0.05);border:1px solid #e5e7eb;text-align:center;transition:all 0.3s;}
        .stat-card:hover{transform:translateY(-5px);box-shadow:0 10px 40px rgba(0,0,0,0.08);}
        .stat-card .stat-icon{font-size:2.5rem;margin-bottom:10px;}
        .stat-card .stat-number{font-size:2rem;font-weight:700;color:#1a1a1a;}
        .stat-card .stat-label{font-size:14px;color:#6b7280;margin-top:5px;}
        .stat-card.bg-red .stat-icon{color:#dc2626;}
        .stat-card.bg-blue .stat-icon{color:#3b82f6;}
        .stat-card.bg-green .stat-icon{color:#22c55e;}
        .stat-card.bg-yellow .stat-icon{color:#eab308;}
        .menu-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:25px;margin-top:20px;}
        .menu-card{background:#fff;border-radius:16px;padding:25px;border:1px solid #e5e7eb;transition:all 0.3s;text-decoration:none;color:#1a1a1a;display:flex;flex-direction:column;align-items:center;text-align:center;}
        .menu-card:hover{transform:translateY(-8px);box-shadow:0 15px 50px rgba(0,0,0,0.1);border-color:#dc2626;}
        .menu-card .menu-icon{width:70px;height:70px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;margin-bottom:15px;}
        .menu-card .menu-icon.icon-red{background:#fef2f2;color:#dc2626;}
        .menu-card .menu-icon.icon-blue{background:#eff6ff;color:#3b82f6;}
        .menu-card .menu-icon.icon-green{background:#f0fdf4;color:#22c55e;}
        .menu-card .menu-icon.icon-purple{background:#f5f3ff;color:#8b5cf6;}
        .menu-card .menu-icon.icon-orange{background:#fff7ed;color:#f97316;}
        .menu-card .menu-icon.icon-teal{background:#ecfdf5;color:#14b8a6;}
        .menu-card .menu-title{font-size:1.1rem;font-weight:700;margin-bottom:5px;}
        .menu-card .menu-desc{font-size:13px;color:#6b7280;line-height:1.6;}
        .menu-card .menu-count{font-size:12px;color:#dc2626;font-weight:600;margin-top:8px;background:#fef2f2;padding:2px 12px;border-radius:12px;display:inline-block;}
        .card-custom{background:#fff;border-radius:16px;padding:2rem;border:1px solid #e5e7eb;margin-bottom:2rem;}
        .card-title{font-size:1.3rem;font-weight:700;color:#1a1a1a;margin-bottom:1.5rem;padding-bottom:0.8rem;border-bottom:2px solid #f3f4f6;display:flex;align-items:center;gap:10px;}
        .card-title i{color:#dc2626;}
        .quick-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-top:15px;}
        .quick-btn{background:#f8fafc;border:2px dashed #d1d5db;border-radius:12px;padding:15px;text-align:center;text-decoration:none;color:#1a1a1a;transition:all 0.3s;font-weight:600;font-size:14px;}
        .quick-btn:hover{background:#dc2626;color:#fff;border-color:#dc2626;}
        .quick-btn i{font-size:1.2rem;display:block;margin-bottom:8px;}
        @media(max-width:768px){.container-custom{padding:1rem;}.page-title{font-size:1.6rem;}}
        @media(max-width:576px){.container-custom{padding:0.8rem;}.page-title{font-size:1.3rem;}.menu-grid{grid-template-columns:1fr;}}
    </style>
</head>
<body>

<?php require_once "../Admin/layouts/header.php"; ?>

<div class="container-custom">

    <div class="page-header">
        <h1 class="page-title"><i class="fas fa-tachometer-alt"></i> پنل مدیریت</h1>
        <div class="header-badge"><i class="fas fa-store"></i> <?= htmlspecialchars($settings['title'] ?? 'فروشگاه ارن') ?></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card bg-red">
            <div class="stat-icon"><i class="fas fa-box"></i></div>
            <div class="stat-number"><?= $productsCount ?></div>
            <div class="stat-label">محصولات</div>
        </div>
        <div class="stat-card bg-blue">
            <div class="stat-icon"><i class="fas fa-tags"></i></div>
            <div class="stat-number"><?= $categoriesCount ?></div>
            <div class="stat-label">دسته‌بندی</div>
        </div>
        <div class="stat-card bg-green">
            <div class="stat-icon"><i class="fas fa-building"></i></div>
            <div class="stat-number"><?= $brandsCount ?></div>
            <div class="stat-label">برندها</div>
        </div>
        <div class="stat-card bg-yellow">
            <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
            <div class="stat-number"><?= $ordersCount ?></div>
            <div class="stat-label">سفارشات</div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-title"><i class="fas fa-th-large"></i> منوی مدیریت</div>
        <div class="menu-grid">

            <a href="/shop/Admin/products/index.php" class="menu-card">
                <div class="menu-icon icon-red"><i class="fas fa-box"></i></div>
                <div class="menu-title">مدیریت محصولات</div>
                <div class="menu-desc">افزودن، ویرایش و حذف محصولات</div>
                <span class="menu-count"><?= $productsCount ?> محصول</span>
            </a>

            <a href="/shop/Admin/categoris/index.php" class="menu-card">
                <div class="menu-icon icon-blue"><i class="fas fa-tags"></i></div>
                <div class="menu-title">مدیریت دسته‌بندی</div>
                <div class="menu-desc">افزودن، ویرایش و حذف دسته‌بندی‌ها</div>
                <span class="menu-count"><?= $categoriesCount ?> دسته</span>
            </a>

            <a href="/shop/Admin/brands/index.php" class="menu-card">
                <div class="menu-icon icon-green"><i class="fas fa-building"></i></div>
                <div class="menu-title">مدیریت برندها</div>
                <div class="menu-desc">افزودن، ویرایش و حذف برندها</div>
                <span class="menu-count"><?= $brandsCount ?> برند</span>
            </a>

            <a href="/shop/Admin/settings/index.php" class="menu-card">
                <div class="menu-icon icon-purple"><i class="fas fa-cog"></i></div>
                <div class="menu-title">تنظیمات سایت</div>
                <div class="menu-desc">ویرایش عنوان، لوگو، فوتر و اطلاعات تماس</div>
                <span class="menu-count">تنظیمات</span>
            </a>

            <a href="/shop/Admin/orders/index.php" class="menu-card">
                <div class="menu-icon icon-orange"><i class="fas fa-shopping-cart"></i></div>
                <div class="menu-title">مدیریت سفارشات</div>
                <div class="menu-desc">مشاهده و مدیریت سفارشات</div>
                <span class="menu-count"><?= $ordersCount ?> سفارش</span>
            </a>

            <a href="/shop/Admin/users/index.php" class="menu-card">
                <div class="menu-icon icon-teal"><i class="fas fa-users"></i></div>
                <div class="menu-title">مدیریت کاربران</div>
                <div class="menu-desc">مشاهده و مدیریت کاربران</div>
                <span class="menu-count">کاربران</span>
            </a>

        </div>
    </div>

    <div class="card-custom">
        <div class="card-title"><i class="fas fa-bolt"></i> دسترسی سریع</div>
        <div class="quick-actions">
            <a href="/shop/Admin/products/index.php" class="quick-btn"><i class="fas fa-plus-circle"></i> افزودن محصول</a>
            <a href="/shop/Admin/categoris/index.php" class="quick-btn"><i class="fas fa-plus-circle"></i> افزودن دسته</a>
            <a href="/shop/Admin/brands/index.php" class="quick-btn"><i class="fas fa-plus-circle"></i> افزودن برند</a>
            <a href="/shop/Admin/settings/index.php" class="quick-btn"><i class="fas fa-cog"></i> تنظیمات سایت</a>
        </div>
    </div>

</div>

</body>
</html>