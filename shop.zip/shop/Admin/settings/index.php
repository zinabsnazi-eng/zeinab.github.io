<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();

if (!$settings) {
    $conn->query("INSERT INTO `settings` (`title`, `description`, `address`, `phone`, `email`, `footer_text`) VALUES ('فروشگاه ارن', 'بهترین فروشگاه آنلاین', 'تهران، خیابان ولیعصر، پلاک ۱۲۳', '۰۲۱-۱۲۳۴۵۶۷۸', 'info@arn.shop', 'تمامی حقوق محفوظ است | ارن')");
    $settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت تنظیمات · ارن</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f5f5f5;color:#1a1a1a;}
        .container-custom{max-width:1200px;margin:0 auto;padding:2rem;}
        .page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:2.5rem;padding-bottom:1.5rem;border-bottom:3px solid #dc2626;flex-wrap:wrap;gap:15px;}
        .page-title{font-size:2.5rem;font-weight:700;color:#1a1a1a;display:flex;align-items:center;gap:12px;}
        .page-title i{color:#dc2626;font-size:2.2rem;}
        .header-badge{font-size:14px;color:#6b7280;background:#f3f4f6;padding:8px 18px;border-radius:10px;display:flex;align-items:center;gap:8px;}
        .header-badge i{color:#dc2626;}
        .card-custom{background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.06);padding:2rem;border:1px solid #e5e7eb;transition:all 0.3s ease;margin-bottom:2rem;}
        .card-custom:hover{box-shadow:0 8px 40px rgba(0,0,0,0.08);}
        .card-custom .card-title{font-size:1.3rem;font-weight:700;color:#1a1a1a;margin-bottom:1.5rem;padding-bottom:0.8rem;border-bottom:2px solid #f3f4f6;display:flex;align-items:center;gap:10px;}
        .card-custom .card-title i{color:#dc2626;}
        .form-group-custom{margin-bottom:20px;}
        .form-group-custom label{font-weight:600;font-size:14px;color:#1a1a1a;display:block;margin-bottom:8px;}
        .form-group-custom label i{color:#dc2626;margin-left:8px;}
        .form-control-custom{width:100%;padding:12px 16px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;transition:all 0.3s ease;background:#fafafa;color:#1a1a1a;font-family:inherit;}
        .form-control-custom:focus{border-color:#dc2626;outline:none;box-shadow:0 0 0 4px rgba(220,38,38,0.1);background:#fff;}
        .form-control-custom[type="file"]{padding:10px;background:#fafafa;}
        textarea.form-control-custom{resize:vertical;min-height:80px;}
        .btn-success-custom{background:#dc2626;color:#fff;padding:12px 40px;border:none;border-radius:12px;font-weight:700;font-size:16px;transition:all 0.3s ease;cursor:pointer;display:inline-flex;align-items:center;gap:10px;}
        .btn-success-custom:hover{background:#b91c1c;transform:translateY(-2px);box-shadow:0 8px 30px rgba(220,38,38,0.3);color:#fff;}
        .alert-custom{padding:14px 20px;border-radius:12px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:10px;}
        .alert-success-custom{background:#f0fdf4;color:#166534;border-right:4px solid #22c55e;}
        .alert-success-custom i{color:#22c55e;}
        .alert-danger-custom{background:#fef2f2;color:#991b1b;border-right:4px solid #ef4444;}
        .alert-danger-custom i{color:#ef4444;}
        .row-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
        .current-logo{width:80px;height:80px;border-radius:12px;object-fit:contain;border:3px solid #dc2626;margin-top:8px;background:#fafafa;padding:5px;}
        .logo-label{font-size:13px;color:#6b7280;margin-top:5px;display:block;}
        .preview-box{background:#fafafa;border-radius:12px;padding:12px;border:1px solid #e5e7eb;margin-top:8px;}
        .preview-box img{max-height:60px;max-width:100%;object-fit:contain;}
        @media(max-width:768px){.row-grid{grid-template-columns:1fr;}.container-custom{padding:1rem;}.page-title{font-size:1.6rem;}.card-custom{padding:1.2rem;}}
        @media(max-width:576px){.container-custom{padding:0.8rem;}.page-title{font-size:1.3rem;}.card-custom{padding:0.8rem;}}
    </style>
</head>
<body>

<div class="container-custom">

    <div class="page-header">
        <h1 class="page-title"><i class="fas fa-cog"></i> مدیریت تنظیمات</h1>
        <div class="header-badge"><i class="fas fa-store"></i> هدر و فوتر</div>
    </div>

    <div class="card-custom">
        <div class="card-title"><i class="fas fa-edit"></i> ویرایش تنظیمات</div>

        <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
            <div class="alert-custom alert-success-custom"><i class="fas fa-check-circle"></i> <?= $_SESSION['done'] ?><?php $_SESSION['done'] = ""; ?></div>
        <?php elseif (!empty($_SESSION['error']) && isset($_SESSION['error'])): ?>
            <div class="alert-custom alert-danger-custom"><i class="fas fa-exclamation-circle"></i> <?= $_SESSION['error'] ?><?php $_SESSION['error'] = ""; ?></div>
        <?php endif; ?>

        <form action="<?= Url("Controllers/settings/updateController.php") ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $settings['id'] ?>">

            <div class="row-grid">
                <div class="form-group-custom">
                    <label><i class="fas fa-heading"></i> عنوان فروشگاه</label>
                    <input name="title" type="text" class="form-control-custom" value="<?= htmlspecialchars($settings['title']) ?>" required>
                </div>
                <div class="form-group-custom">
                    <label><i class="fas fa-image"></i> لوگو</label>
                    <input name="logo" type="file" class="form-control-custom" accept="image/*">
                    <?php if (!empty($settings['logo']) && file_exists("../../Public/setting_logo/" . $settings['logo'])): ?>
                        <span class="logo-label">لوگو فعلی:</span>
                        <img class="current-logo" src="<?= Assets("setting_logo/" . $settings['logo']) ?>" alt="لوگو">
                    <?php endif; ?>
                </div>
                <div class="form-group-custom" style="grid-column:1/-1;">
                    <label><i class="fas fa-align-left"></i> توضیحات (زیر عنوان در فوتر)</label>
                    <textarea name="description" class="form-control-custom" rows="2"><?= htmlspecialchars($settings['description']) ?></textarea>
                </div>
                <div class="form-group-custom" style="grid-column:1/-1;">
                    <label><i class="fas fa-map-marker-alt"></i> آدرس</label>
                    <textarea name="address" class="form-control-custom" rows="2"><?= htmlspecialchars($settings['address']) ?></textarea>
                </div>
                <div class="form-group-custom">
                    <label><i class="fas fa-phone"></i> شماره تماس</label>
                    <input name="phone" type="text" class="form-control-custom" value="<?= htmlspecialchars($settings['phone']) ?>">
                </div>
                <div class="form-group-custom">
                    <label><i class="fas fa-envelope"></i> ایمیل</label>
                    <input name="email" type="email" class="form-control-custom" value="<?= htmlspecialchars($settings['email'] ?? '') ?>">
                </div>
                <div class="form-group-custom">
                    <label><i class="fab fa-instagram"></i> اینستاگرام</label>
                    <input name="instagram" type="url" class="form-control-custom" value="<?= htmlspecialchars($settings['instagram'] ?? '') ?>" placeholder="https://instagram.com/...">
                </div>
                <div class="form-group-custom">
                    <label><i class="fab fa-telegram"></i> تلگرام</label>
                    <input name="telegram" type="url" class="form-control-custom" value="<?= htmlspecialchars($settings['telegram'] ?? '') ?>" placeholder="https://t.me/...">
                </div>
                <div class="form-group-custom">
                    <label><i class="fab fa-whatsapp"></i> واتساپ</label>
                    <input name="whatsapp" type="url" class="form-control-custom" value="<?= htmlspecialchars($settings['whatsapp'] ?? '') ?>" placeholder="https://wa.me/...">
                </div>
                <div class="form-group-custom">
                    <label><i class="fab fa-facebook"></i> فیسبوک</label>
                    <input name="facebook" type="url" class="form-control-custom" value="<?= htmlspecialchars($settings['facebook'] ?? '') ?>" placeholder="https://facebook.com/...">
                </div>
                <div class="form-group-custom" style="grid-column:1/-1;">
                    <label><i class="fas fa-copyright"></i> متن فوتر (کپی‌رایت)</label>
                    <input name="footer_text" type="text" class="form-control-custom" value="<?= htmlspecialchars($settings['footer_text'] ?? 'تمامی حقوق محفوظ است | ارن') ?>">
                </div>
            </div>

            <button type="submit" class="btn-success-custom"><i class="fas fa-save"></i> ذخیره تغییرات</button>
        </form>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>