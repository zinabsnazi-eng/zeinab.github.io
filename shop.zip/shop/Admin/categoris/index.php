<?php
require_once "../../Config/conf.php";
require_once "../../Config/helpers.php";

$categories = $conn->query("SELECT * FROM `categoris` ORDER BY `id` DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دسته‌بندی · ارن</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php
    require_once "../layouts/header.php";
    ?> 
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #1a1a1a;
            line-height: 1.6;
        }

        .container-custom {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 3px solid #dc2626;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            color: #dc2626;
            font-size: 2.2rem;
        }

        .header-badge {
            font-size: 14px;
            color: #6b7280;
            background: #f3f4f6;
            padding: 8px 18px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .header-badge i {
            color: #dc2626;
        }

        .card-custom {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            padding: 2rem;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            margin-bottom: 2rem;
        }

        .card-custom:hover {
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.08);
        }

        .card-custom .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            padding-bottom: 0.8rem;
            border-bottom: 2px solid #f3f4f6;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-custom .card-title i {
            color: #dc2626;
        }

        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-custom {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 14px;
            min-width: 700px;
        }

        .table-custom thead th {
            background: #1a1a1a;
            color: #ffffff;
            padding: 16px 20px;
            font-weight: 600;
            text-align: center;
            border: none;
            white-space: nowrap;
            font-size: 13px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .table-custom thead th:first-child {
            border-radius: 12px 0 0 0;
        }

        .table-custom thead th:last-child {
            border-radius: 0 12px 0 0;
        }

        .table-custom tbody tr {
            background: #ffffff;
            transition: all 0.2s ease;
            border-bottom: 1px solid #f3f4f6;
        }

        .table-custom tbody tr:hover {
            background: #fafafa;
        }

        .table-custom tbody td {
            padding: 16px 20px;
            text-align: center;
            color: #1a1a1a;
            border: none;
            vertical-align: middle;
            font-size: 14px;
        }

        .table-custom tbody td:first-child {
            font-weight: 600;
            color: #dc2626;
        }

        .table-img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            object-fit: cover;
            border: 2px solid #e5e7eb;
            transition: all 0.3s ease;
        }

        .table-img:hover {
            transform: scale(1.8);
            border-color: #dc2626;
            box-shadow: 0 8px 30px rgba(220, 38, 38, 0.2);
            z-index: 10;
            position: relative;
        }

        .btn-edit {
            background: #dc2626;
            color: #ffffff;
            padding: 8px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin: 0 3px;
        }

        .btn-edit:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(220, 38, 38, 0.3);
            color: #ffffff;
        }

        .btn-edit i {
            font-size: 12px;
        }

        .btn-delete {
            background: #ef4444;
            color: #ffffff;
            padding: 8px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin: 0 3px;
        }

        .btn-delete:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
            color: #ffffff;
        }

        .btn-delete i {
            font-size: 12px;
        }

        .btn-success-custom {
            background: #dc2626;
            color: #ffffff;
            padding: 12px 40px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-success-custom:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(220, 38, 38, 0.3);
            color: #ffffff;
        }

        .btn-secondary-custom {
            background: #f3f4f6;
            color: #1a1a1a;
            padding: 10px 25px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-secondary-custom:hover {
            background: #e5e7eb;
        }

        .btn-danger-custom {
            background: #ef4444;
            color: #ffffff;
            padding: 10px 25px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-danger-custom:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
            color: #ffffff;
        }

        .modal-content-custom {
            border-radius: 20px;
            border: none;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
        }

        .modal-header-custom {
            background: #1a1a1a;
            color: #ffffff;
            padding: 20px 30px;
            border-radius: 20px 20px 0 0;
            border: none;
        }

        .modal-header-custom h5 {
            font-weight: 700;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header-custom h5 i {
            color: #dc2626;
        }

        .modal-header-custom .btn-close {
            filter: brightness(0) invert(1);
        }

        .modal-body-custom {
            padding: 30px;
        }

        .modal-footer-custom {
            padding: 15px 30px 25px;
            border-top: 1px solid #e5e7eb;
            border-radius: 0 0 20px 20px;
        }

        .form-group-custom {
            margin-bottom: 20px;
        }

        .form-group-custom label {
            font-weight: 600;
            font-size: 14px;
            color: #1a1a1a;
            display: block;
            margin-bottom: 8px;
        }

        .form-group-custom label i {
            color: #dc2626;
            margin-left: 8px;
        }

        .form-control-custom {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #fafafa;
            color: #1a1a1a;
            font-family: inherit;
        }

        .form-control-custom:focus {
            border-color: #dc2626;
            outline: none;
            box-shadow: 0 0 0 4px rgba(220, 38, 38, 0.1);
            background: #ffffff;
        }

        .form-control-custom[type="file"] {
            padding: 10px;
            background: #fafafa;
        }

        textarea.form-control-custom {
            resize: vertical;
            min-height: 80px;
        }

        .alert-custom {
            padding: 14px 20px;
            border-radius: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success-custom {
            background: #f0fdf4;
            color: #166534;
            border-right: 4px solid #22c55e;
        }

        .alert-success-custom i {
            color: #22c55e;
        }

        .alert-danger-custom {
            background: #fef2f2;
            color: #991b1b;
            border-right: 4px solid #ef4444;
        }

        .alert-danger-custom i {
            color: #ef4444;
        }

        .row-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
        }

        .empty-state i {
            font-size: 4rem;
            color: #dc2626;
            margin-bottom: 15px;
        }

        .empty-state h3 {
            font-size: 1.3rem;
            color: #1a1a1a;
            margin-bottom: 8px;
        }

        .empty-state p {
            color: #6b7280;
        }

        .current-logo {
            width: 70px;
            height: 70px;
            border-radius: 12px;
            object-fit: cover;
            border: 3px solid #dc2626;
            margin-top: 8px;
        }

        .logo-label {
            font-size: 13px;
            color: #6b7280;
            margin-top: 5px;
            display: block;
        }

        @media (max-width: 992px) {
            .container-custom {
                padding: 1.5rem;
            }

            .page-title {
                font-size: 2rem;
            }

            .table-custom thead th,
            .table-custom tbody td {
                padding: 12px 15px;
                font-size: 13px;
            }

            .table-img {
                width: 40px;
                height: 40px;
            }
        }

        @media (max-width: 768px) {
            .container-custom {
                padding: 1rem;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .page-title {
                font-size: 1.6rem;
            }

            .card-custom {
                padding: 1.2rem;
            }

            .card-custom .card-title {
                font-size: 1.1rem;
            }

            .table-custom {
                font-size: 12px;
                min-width: 600px;
            }

            .table-custom thead th,
            .table-custom tbody td {
                padding: 10px 12px;
                font-size: 12px;
                white-space: nowrap;
            }

            .table-img {
                width: 32px;
                height: 32px;
            }

            .btn-edit,
            .btn-delete {
                padding: 6px 14px;
                font-size: 11px;
            }

            .modal-body-custom {
                padding: 20px;
            }

            .row-grid {
                grid-template-columns: 1fr;
            }

            .btn-success-custom {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .container-custom {
                padding: 0.8rem;
            }

            .page-title {
                font-size: 1.3rem;
            }

            .card-custom {
                padding: 0.8rem;
            }

            .card-custom .card-title {
                font-size: 1rem;
            }

            .table-custom {
                font-size: 10px;
                min-width: 500px;
            }

            .table-custom thead th,
            .table-custom tbody td {
                padding: 6px 8px;
                font-size: 10px;
            }

            .table-img {
                width: 25px;
                height: 25px;
                border-width: 1px;
            }

            .btn-edit,
            .btn-delete {
                padding: 4px 10px;
                font-size: 9px;
                border-radius: 6px;
                margin: 2px;
            }

            .modal-header-custom h5 {
                font-size: 1.1rem;
            }

            .modal-body-custom {
                padding: 15px;
            }

            .form-group-custom label {
                font-size: 13px;
            }

            .form-control-custom {
                font-size: 12px;
                padding: 8px 12px;
            }

            .btn-success-custom {
                padding: 10px 20px;
                font-size: 14px;
            }

            .current-logo {
                width: 50px;
                height: 50px;
            }
        }
    </style>
</head>
<body>

<div class="container-custom">

    <div class="page-header">
        <h1 class="page-title">
            <i class="fas fa-tags"></i>
            دسته‌بندی موبایل
        </h1>
        <div class="header-badge">
            <i class="fas fa-store"></i>
            مدیریت دسته‌بندی
        </div>
    </div>

    <!-- لیست دسته‌بندی‌ها -->
    <div class="card-custom">
        <div class="card-title">
            <i class="fas fa-list"></i>
            لیست دسته‌بندی‌ها
            <span style="font-size:14px; font-weight:400; color:#6b7280; margin-right:auto;">
                تعداد: <?= count($categories) ?>
            </span>
        </div>

        <?php if (count($categories) > 0): ?>
            <div class="table-wrapper">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>آیدی</th>
                            <th>عنوان</th>
                            <th>تصویر</th>
                            <th>توضیحات</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?= $category['id'] ?></td>
                                <td><strong><?= htmlspecialchars($category['title']) ?></strong></td>
                                <td>
                                    <?php if (!empty($category['image']) && $category['image'] != "default-image.jpg" && file_exists("../../Public/categoris_images/" . $category['image'])): ?>
                                        <img class="table-img" src="<?= Assets("categoris_images/" . $category['image']) ?>" alt="تصویر دسته بندی">
                                    <?php else: ?>
                                        <img class="table-img" src="<?= Assets("categoris_images/default-image.jpg") ?>" alt="تصویر پیش‌فرض">
                                    <?php endif; ?>
                                </td>
                                <td style="max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                                    <?= htmlspecialchars($category['description']) ?>
                                </td>
                                <td>
                                    <button type="button" class="btn-edit" data-bs-toggle="modal" data-bs-target="#updateModal<?= $category['id'] ?>">
                                        <i class="fas fa-pen"></i>
                                        ویرایش
                                    </button>
                                    <button type="button" class="btn-delete" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $category['id'] ?>">
                                        <i class="fas fa-trash"></i>
                                        حذف
                                    </button>
                                </td>
                            </tr>

                            <!-- مودال ویرایش -->
                            <div class="modal fade" id="updateModal<?= $category['id'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content modal-content-custom">
                                        <div class="modal-header modal-header-custom">
                                            <h5>
                                                <i class="fas fa-edit"></i>
                                                ویرایش دسته‌بندی
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body modal-body-custom">

                                            <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
                                                <div class="alert-custom alert-success-custom">
                                                    <i class="fas fa-check-circle"></i>
                                                    <?= $_SESSION['done'] ?>
                                                    <?php $_SESSION['done'] = ""; ?>
                                                </div>
                                            <?php elseif (!empty($_SESSION['error']) && isset($_SESSION['error'])): ?>
                                                <div class="alert-custom alert-danger-custom">
                                                    <i class="fas fa-exclamation-circle"></i>
                                                    <?= $_SESSION['error'] ?>
                                                    <?php $_SESSION['error'] = ""; ?>
                                                </div>
                                            <?php endif; ?>

                                            <form action="<?= Url("Controllers/categoris/updateController.php") ?>" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="id" value="<?= $category['id'] ?>">

                                                <div class="form-group-custom">
                                                    <label><i class="fas fa-heading"></i>عنوان دسته‌بندی</label>
                                                    <input name="title" value="<?= htmlspecialchars($category['title']) ?>" type="text" class="form-control-custom" required>
                                                </div>

                                                <div class="form-group-custom">
                                                    <label><i class="fas fa-image"></i>تصویر</label>
                                                    <input name="image" type="file" class="form-control-custom" accept="image/*">
                                                    <?php if (!empty($category['image']) && $category['image'] != "default-image.jpg" && file_exists("../../Public/categoris_images/" . $category['image'])): ?>
                                                        <span class="logo-label">تصویر فعلی:</span>
                                                        <img class="current-logo" src="<?= Assets("categoris_images/" . $category['image']) ?>" alt="تصویر فعلی">
                                                    <?php else: ?>
                                                        <span class="logo-label">تصویری برای این دسته‌بندی وجود ندارد</span>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group-custom">
                                                    <label><i class="fas fa-align-left"></i>توضیحات</label>
                                                    <textarea name="description" class="form-control-custom" rows="2"><?= htmlspecialchars($category['description']) ?></textarea>
                                                </div>

                                                <button type="submit" class="btn-success-custom" style="width:100%;">
                                                    <i class="fas fa-save"></i>
                                                    ذخیره تغییرات
                                                </button>
                                            </form>
                                        </div>
                                        <div class="modal-footer modal-footer-custom">
                                            <button type="button" class="btn-secondary-custom" data-bs-dismiss="modal">
                                                <i class="fas fa-times"></i>
                                                بستن
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                             <!-- مودال حذف -->
<div class="modal fade" id="deleteModal<?= $category['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom">
            <div class="modal-header modal-header-custom">
                <h5>
                    <i class="fas fa-trash"></i>
                    حذف دسته‌بندی
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body modal-body-custom">
                <p style="font-size:16px; color:#1a1a1a; text-align:center; padding:15px 0;">
                    آیا از حذف دسته‌بندی
                    <strong style="color:#dc2626;"><?= htmlspecialchars($category['title']) ?></strong>
                    مطمئن هستید؟
                </p>
            </div>
            <div class="modal-footer modal-footer-custom">
                <button type="button" class="btn-secondary-custom" data-bs-dismiss="modal">
                    <i class="fas fa-times"></i>
                    انصراف
                </button>
                <a class="btn-danger-custom" href="/shop/Controllers/categoris/deleteController.php?id=<?= $category['id'] ?>">
                    <i class="fas fa-trash"></i>
                    حذف
                </a>
            </div>
        </div>
    </div>
</div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-folder-open"></i>
                <h3>هیچ دسته‌بندی یافت نشد!</h3>
                <p>دسته‌بندی جدید را از فرم زیر اضافه کنید.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- افزودن دسته‌بندی جدید -->
    <div class="card-custom">
        <div class="card-title">
            <i class="fas fa-plus-circle"></i>
            افزودن دسته‌بندی جدید
        </div>

        <?php if (!empty($_SESSION['done']) && $_SESSION['done'] != ""): ?>
            <div class="alert-custom alert-success-custom">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['done'] ?>
                <?php $_SESSION['done'] = ""; ?>
            </div>
        <?php elseif (!empty($_SESSION['error']) && isset($_SESSION['error'])): ?>
            <div class="alert-custom alert-danger-custom">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error'] ?>
                <?php $_SESSION['error'] = ""; ?>
            </div>
        <?php endif; ?>

        <form action="<?= Url("Controllers/categoris/insertController.php") ?>" method="POST" enctype="multipart/form-data">
            <div class="row-grid">
                <div class="form-group-custom">
                    <label><i class="fas fa-heading"></i>عنوان</label>
                    <input name="title" type="text" class="form-control-custom" placeholder="مثال: گوشی موبایل" required>
                </div>
                <div class="form-group-custom">
                    <label><i class="fas fa-image"></i>تصویر</label>
                    <input name="image" type="file" class="form-control-custom" accept="image/*">
                </div>
                <div class="form-group-custom" style="grid-column: 1 / -1;">
                    <label><i class="fas fa-align-left"></i>توضیحات</label>
                    <textarea name="description" class="form-control-custom" rows="2" placeholder="توضیحات دسته‌بندی"></textarea>
                </div>
            </div>
            <button type="submit" class="btn-success-custom">
                <i class="fas fa-plus"></i>
                افزودن دسته‌بندی
            </button>
        </form>
    </div>

</div>
<?php
require_once "../layouts/footer.php";
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>