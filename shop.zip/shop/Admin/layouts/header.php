<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();
?>
<header class="bg-white shadow-sm sticky top-0 z-50">
    <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <a href="/shop/Admin/index.php" class="text-2xl font-bold text-red-600">
                    <?php if (!empty($settings['logo']) && $settings['logo'] != "default-logo.png" && file_exists("Public/setting_logo/" . $settings['logo'])): ?>
                        <img src="<?= Assets("setting_logo/" . $settings['logo']) ?>" alt="<?= htmlspecialchars($settings['title']) ?>" style="height:35px;">
                    <?php else: ?>
                        <?= htmlspecialchars($settings['title'] ?? 'ارن') ?>
                    <?php endif; ?>
                </a>
                <span class="mr-2 text-xs text-gray-500 hidden sm:inline">پنل مدیریت</span>
            </div>

            <div class="flex items-center space-x-4 space-x-reverse">
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'admin'): ?>
                    <span class="text-sm text-gray-600 hidden sm:inline">
                        <i class="fas fa-user-circle text-red-600"></i>
                        <?= htmlspecialchars($_SESSION['fullname'] ?? 'مدیر') ?>
                    </span>
                    <a href="/shop/Admin/index.php" class="text-gray-700 hover:text-red-600">
                        <i class="fas fa-tachometer-alt text-xl"></i>
                    </a>
                    <a href="/shop/logout.php" class="text-gray-700 hover:text-red-600" onclick="return confirm('آیا از خروج مطمئن هستید؟')">
                        <i class="fas fa-sign-out-alt text-xl"></i>
                    </a>
                <?php else: ?>
                    <a href="/shop/login.php" class="text-gray-700 hover:text-red-600">
                        <i class="fas fa-sign-in-alt text-xl"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>