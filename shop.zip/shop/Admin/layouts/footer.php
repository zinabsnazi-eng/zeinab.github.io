<?php
$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();
?>
<footer style="background:#1a1a1a; color:white; padding:40px 0 20px 0; margin-top:30px;">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            
            <div>
                <h4 style="font-size:20px; font-weight:700; margin-bottom:10px;">
                    <?php if (!empty($settings['logo']) && $settings['logo'] != "default-logo.png"): ?>
                        <img src="<?= Assets("setting_logo/" . $settings['logo']) ?>" alt="<?= htmlspecialchars($settings['title']) ?>" style="height:35px;">
                    <?php else: ?>
                        <?= htmlspecialchars($settings['title'] ?? 'ارن') ?>
                    <?php endif; ?>
                </h4>
                <p style="color:#9ca3af; font-size:14px; margin-bottom:15px;"><?= htmlspecialchars($settings['description'] ?? '') ?></p>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">درباره ما</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">تماس با ما</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">حریم خصوصی</a>
            </div>

            <div>
                <h4 style="font-size:18px; font-weight:700; margin-bottom:15px;">خدمات مشتریان</h4>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">راهنما</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">پرسش‌های متداول</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">بازگشت کالا</a>
                <a href="#" style="color:#9ca3af; text-decoration:none; font-size:14px; display:block; margin-bottom:8px;">گارانتی</a>
            </div>

            <div>
                <h4 style="font-size:18px; font-weight:700; margin-bottom:15px;">راه‌های ارتباطی</h4>
                <p style="color:#9ca3af; font-size:14px; margin-bottom:8px;"><i class="fas fa-phone ml-2" style="color:#dc2626;"></i> <?= htmlspecialchars($settings['phone'] ?? '') ?></p>
                <p style="color:#9ca3af; font-size:14px; margin-bottom:8px;"><i class="fas fa-envelope ml-2" style="color:#dc2626;"></i> <?= htmlspecialchars($settings['email'] ?? '') ?></p>
                <p style="color:#9ca3af; font-size:14px;"><i class="fas fa-map-marker-alt ml-2" style="color:#dc2626;"></i> <?= htmlspecialchars($settings['address'] ?? '') ?></p>
            </div>

            <div>
                <h4 style="font-size:18px; font-weight:700; margin-bottom:15px;">ما را دنبال کنید</h4>
                <div style="display:flex; gap:10px; margin-bottom:20px;">
                    <?php if (!empty($settings['instagram'])): ?>
                        <a href="<?= htmlspecialchars($settings['instagram']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['telegram'])): ?>
                        <a href="<?= htmlspecialchars($settings['telegram']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-telegram"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['whatsapp'])): ?>
                        <a href="<?= htmlspecialchars($settings['whatsapp']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-whatsapp"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['facebook'])): ?>
                        <a href="<?= htmlspecialchars($settings['facebook']) ?>" target="_blank" style="width:40px;height:40px;background:#374151;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:white;transition:0.3s;"><i class="fab fa-facebook-f"></i></a>
                    <?php endif; ?>
                </div>
                <div>
                    <h5 style="font-weight:600; margin-bottom:10px; font-size:14px;">دانلود اپلیکیشن</h5>
                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <a href="#" style="background:black; border-radius:8px; padding:8px 15px; font-size:12px; color:white; text-decoration:none; display:inline-flex; align-items:center; gap:8px;"><i class="fab fa-apple"></i> App Store</a>
                        <a href="#" style="background:black; border-radius:8px; padding:8px 15px; font-size:12px; color:white; text-decoration:none; display:inline-flex; align-items:center; gap:8px;"><i class="fab fa-google-play"></i> Google Play</a>
                    </div>
                </div>
            </div>

        </div>

        <div style="border-top:1px solid #374151; padding-top:20px; margin-top:30px;">
            <div style="text-align:center; color:#9ca3af; font-size:14px;">
                <p><?= htmlspecialchars($settings['footer_text'] ?? 'تمامی حقوق محفوظ است | ارن') ?></p>
                <div style="display:flex; justify-content:center; gap:15px; margin-top:8px;">
                    <a href="#" style="color:#9ca3af; text-decoration:none;">شرایط استفاده</a>
                    <a href="#" style="color:#9ca3af; text-decoration:none;">قوانین</a>
                    <a href="#" style="color:#9ca3af; text-decoration:none;">حریم خصوصی</a>
                </div>
            </div>
        </div>
    </div>
</footer>