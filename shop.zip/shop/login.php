<?php
require_once "Config/conf.php";
require_once "Config/helpers.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: /shop/Admin/index.php");
    } else {
        header("Location: /shop/index.php");
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT * FROM `users` WHERE `username` = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user) {
            if ($password == $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['role'] = $user['role'];
                
                if ($user['role'] == 'admin') {
                    header("Location: /shop/Admin/index.php");
                } else {
                    header("Location: /shop/index.php");
                }
                exit;
            } else {
                $error = "رمز عبور اشتباه است!";
            }
        } else {
            $error = "نام کاربری یافت نشد!";
        }
    } else {
        $error = "لطفاً همه فیلدها را پر کنید!";
    }
}

$settings = $conn->query("SELECT * FROM `settings` LIMIT 1")->fetch();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود · <?= htmlspecialchars($settings['title'] ?? 'فروشگاه ارن') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f1f5f9;min-height:100vh;display:flex;align-items:center;justify-content:center;}
        .login-container{background:#fff;border-radius:20px;padding:40px;max-width:420px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.1);border:1px solid #e5e7eb;}
        .login-logo{text-align:center;margin-bottom:30px;}
        .login-logo h1{font-size:2.2rem;font-weight:700;color:#dc2626;}
        .login-logo p{color:#6b7280;font-size:14px;margin-top:5px;}
        .login-title{font-size:1.5rem;font-weight:700;color:#1a1a1a;text-align:center;margin-bottom:25px;}
        .form-group{margin-bottom:20px;}
        .form-group label{display:block;font-weight:600;font-size:14px;color:#1a1a1a;margin-bottom:8px;}
        .form-group label i{color:#dc2626;margin-left:8px;}
        .form-group input{width:100%;padding:12px 16px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;transition:all 0.3s;background:#fafafa;}
        .form-group input:focus{border-color:#dc2626;outline:none;box-shadow:0 0 0 4px rgba(220,38,38,0.1);background:#fff;}
        .btn-login{width:100%;padding:14px;background:#dc2626;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:700;cursor:pointer;transition:all 0.3s;display:flex;align-items:center;justify-content:center;gap:10px;}
        .btn-login:hover{background:#b91c1c;transform:translateY(-2px);box-shadow:0 8px 25px rgba(220,38,38,0.3);}
        .alert-error{background:#fef2f2;color:#991b1b;padding:12px 16px;border-radius:12px;border-right:4px solid #ef4444;margin-bottom:20px;display:flex;align-items:center;gap:10px;font-size:14px;}
        .alert-error i{color:#ef4444;font-size:18px;}
        .login-footer{text-align:center;margin-top:20px;font-size:14px;color:#6b7280;}
        .login-footer a{color:#dc2626;text-decoration:none;font-weight:600;}
        .login-footer a:hover{text-decoration:underline;}
        .input-icon{position:relative;}
        .input-icon i{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:#9ca3af;}
        .input-icon input{padding-right:45px;}
        @media(max-width:480px){.login-container{padding:25px;margin:15px;}}
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-logo">
        <h1><?= htmlspecialchars($settings['title'] ?? 'ارن') ?></h1>
        <p><?= htmlspecialchars($settings['description'] ?? 'خرید هوشمند، زندگی آسان') ?></p>
    </div>

    <h2 class="login-title"><i class="fas fa-user-lock" style="color:#dc2626;margin-left:10px;"></i> ورود به حساب</h2>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?= $_SESSION['error'] ?><?php $_SESSION['error'] = ""; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-group">
            <label><i class="fas fa-user"></i> نام کاربری</label>
            <div class="input-icon">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="نام کاربری خود را وارد کنید" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-lock"></i> رمز عبور</label>
            <div class="input-icon">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="رمز عبور خود را وارد کنید" required>
            </div>
        </div>

        <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> ورود</button>
    </form>

    <div class="login-footer">
        <a href="/shop/index.php"><i class="fas fa-arrow-right"></i> بازگشت به صفحه اصلی</a>
    </div>
</div>

</body>
</html>